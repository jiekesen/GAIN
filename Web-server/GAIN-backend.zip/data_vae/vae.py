import os

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init


class EarlyStopping:
    def __init__(self, patience=20, verbose=False, outdir=None):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.loss_min = np.inf
        self.model_file = os.path.join(outdir, 'model.pt') if outdir else 'model.pt'

    def __call__(self, loss, model):
        if np.isnan(loss):
            self.early_stop = True
            return
        score = -loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(loss, model)
        elif score < self.best_score:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
                # 修正这里！
                model.load_state_dict(torch.load(self.model_file, weights_only=False))
        else:
            self.best_score = score
            self.save_checkpoint(loss, model)
            self.counter = 0

    def save_checkpoint(self, loss, model):
        if self.verbose:
            print(f'Loss decreased ({self.loss_min:.6f} --> {loss:.6f}).  Saving model ...')
        torch.save(model.state_dict(), self.model_file)
        self.loss_min = loss


def compute_kl_divergence(mu, logvar):
    return -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=1)


def compute_elbo_loss(recon_x, x, z_params, binary=True):
    mu, logvar = z_params
    kld = compute_kl_divergence(mu, logvar)
    if binary:
        likelihood = -binary_cross_entropy_loss(recon_x, x)
    else:
        likelihood = -F.mse_loss(recon_x, x)
    return torch.sum(likelihood), torch.sum(kld)


def binary_cross_entropy_loss(recon_x, x):
    return -torch.sum(x * torch.log(recon_x + 1e-8) + (1 - x) * torch.log(1 - recon_x + 1e-8), dim=-1)


def create_mlp(layers, activation=nn.LeakyReLU(), bn=False, dropout=0):
    net = []
    for i in range(1, len(layers)):
        net.append(nn.Linear(layers[i - 1], layers[i]))
        if bn:
            net.append(nn.BatchNorm1d(layers[i]))
        net.append(activation)
        if dropout > 0:
            net.append(nn.Dropout(dropout))
    return nn.Sequential(*net)


class Encoder(nn.Module):
    def __init__(self, dims, bn=False, dropout=0):
        super(Encoder, self).__init__()

        [x_dim, h_dim, z_dim] = dims
        self.hidden = create_mlp([x_dim] + h_dim, bn=bn, dropout=dropout)
        self.sample = GaussianSample(([x_dim] + h_dim)[-1], z_dim)

    def forward(self, x):
        x = self.hidden(x)
        return self.sample(x)


class Decoder(nn.Module):
    def __init__(self, dims, bn=False, dropout=0, output_activation=nn.Sigmoid()):

        super(Decoder, self).__init__()

        [z_dim, h_dim, x_dim] = dims

        self.hidden = create_mlp([z_dim, *h_dim], bn=bn, dropout=dropout)
        self.reconstruction = nn.Linear([z_dim, *h_dim][-1], x_dim)

        self.output_activation = output_activation

    def forward(self, x):
        x = self.hidden(x)
        if self.output_activation is not None:
            return self.output_activation(self.reconstruction(x))
        else:
            return self.reconstruction(x)


class DeterministicWarmup(object):

    def __init__(self, n=100, t_max=1):
        self.t = 0
        self.t_max = t_max
        self.inc = 1 / n

    def __iter__(self):
        return self

    def __next__(self):
        t = self.t + self.inc

        self.t = self.t_max if t > self.t_max else t
        return self.t

    def next(self):
        t = self.t + self.inc

        self.t = self.t_max if t > self.t_max else t
        return self.t


class Stochastic(nn.Module):

    def reparametrize(self, mu, logvar):
        epsilon = torch.randn(mu.size(), requires_grad=False, device=mu.device)
        std = logvar.mul(0.5).exp_()
        z = mu.addcmul(std, epsilon)

        return z


class GaussianSample(Stochastic):

    def __init__(self, in_features, out_features):
        super(GaussianSample, self).__init__()
        self.in_features = in_features
        self.out_features = out_features

        self.mu = nn.Linear(in_features, out_features)
        self.log_var = nn.Linear(in_features, out_features)

    def forward(self, x):
        mu = self.mu(x)
        log_var = self.log_var(x)

        return self.reparametrize(mu, log_var), mu, log_var


class VAE(nn.Module):
    def __init__(self, dims, bn=False, dropout=0, binary=False):
        super(VAE, self).__init__()
        [x_dim, z_dim, encode_dim, decode_dim] = dims
        self.binary = binary
        if binary:
            decode_activation = nn.Sigmoid()
        else:
            decode_activation = None

        self.encoder = Encoder([x_dim, encode_dim, z_dim], bn=bn, dropout=dropout)
        self.decoder = Decoder([z_dim, decode_dim, x_dim], bn=bn, dropout=dropout, output_activation=decode_activation)

        self.initialize_weights()

    def initialize_weights(self):
        """Initialize weights for the linear layers in the network."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                init.xavier_normal_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, x, y=None):
        """Forward pass to encode input and reconstruct."""
        z, mu, logvar = self.encoder(x)
        recon_x = self.decoder(z)
        return recon_x

    def compute_loss(self, x):
        """Compute the reconstruction loss and KL divergence loss."""
        z, mu, logvar = self.encoder(x)
        recon_x = self.decoder(z)
        likelihood, kl_loss = compute_elbo_loss(recon_x, x, (mu, logvar), binary=self.binary)
        return (-likelihood, kl_loss)

    def train_model(self, dataloader,
                    lr=0.002,
                    weight_decay=5e-4,
                    device='cuda',
                    beta=1,
                    warmup_steps=200,
                    max_iter=30000,
                    verbose=True,
                    patience=100,
                    outdir=None):
        """Train the VAE model with the specified parameters."""
        self.to(device)
        optimizer = torch.optim.Adam(self.parameters(), lr=lr, weight_decay=weight_decay)
        beta_scheduler = DeterministicWarmup(n=warmup_steps, t_max=beta)

        iteration = 0
        n_epoch = int(np.ceil(max_iter / len(dataloader)))
        early_stopping = EarlyStopping(patience=patience, outdir=outdir)

        for epoch in range(n_epoch):
            epoch_recon_loss, epoch_kl_loss = 0, 0
            for i, x in enumerate(dataloader):
                x = x.float().to(device)
                optimizer.zero_grad()

                recon_loss, kl_loss = self.compute_loss(x)
                loss = (recon_loss + kl_loss) / len(x)
                loss.backward()
                torch.nn.utils.clip_grad_norm(self.parameters(), 10)  # Clip gradients
                optimizer.step()

                epoch_kl_loss += kl_loss.item()
                epoch_recon_loss += recon_loss.item()

                iteration += 1

    def encode_batch(self, dataloader, device='cpu', output_type='z', transforms=None):
        """Encode a batch of data and return the specified output."""
        output = []
        for x in dataloader:
            x = x.view(x.size(0), -1).float().to(device)
            z, mu, logvar = self.encoder(x)

            if output_type == 'z':
                output.append(z.detach().cpu())
            elif output_type == 'x':
                recon_x = self.decoder(z)
                output.append(recon_x.detach().cpu().data)
            elif output_type == 'logit':
                output.append(self.get_gamma(z)[0].cpu().detach().data)
            elif output_type == 'mu':
                output.append(mu.cpu().detach().data)
            elif output_type == 'log_var':
                output.append(logvar.cpu().detach().data)

        output = torch.cat(output).numpy()
        return output


if torch.cuda.is_available():  # cuda device
    device = 'cuda'
    torch.cuda.set_device(0)
    print(1)
else:
    device = 'cpu'


def load_vae_with_scaler(ckpt_path, device="cpu"):
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)

    # 1) 重建模型
    model = VAE(
        dims=ckpt["dims"],
        bn=ckpt["bn"],
        dropout=ckpt["dropout"],
        binary=ckpt["binary"]
    ).to(device)

    # 2) 加载参数
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    # 3) 取出 scaler
    scaler = ckpt.get("scaler", None)
    if scaler is None:
        raise KeyError("ckpt 中没有 scaler，请确认保存时已写入 'scaler'。")

    # 4) 验证 scaler 是否 fit 过
    if not (hasattr(scaler, "mean_") and hasattr(scaler, "scale_")):
        raise ValueError("ckpt 中 scaler 仍未拟合（缺少 mean_/scale_）。请用训练数据 fit 后再保存。")

    return model, scaler, ckpt


# ====== 使用示例：加载 ======
ckpt_path = "data_vae/vae_pretrain_with_scaler.pt"
vae, scaler, ckpt = load_vae_with_scaler(ckpt_path, device=device)
print("✅ loaded:", ckpt_path)
print("✅ scaler fitted, mean_.shape =", scaler.mean_.shape)


def preprocess_one_sample(X_new, scaler, input_dim):
    X_new = np.asarray(X_new, dtype=np.float32)
    if X_new.ndim == 1:
        X_new = X_new[None, :]
    if X_new.shape[1] != input_dim:
        raise ValueError(f"特征维度不一致: got {X_new.shape[1]}, need {input_dim}")
    X_new = scaler.transform(X_new)
    X_new = np.nan_to_num(X_new).astype(np.float32)
    return X_new


@torch.no_grad()
def encode_one_sample(model, x_new_scaled, device="cpu", return_type="mu"):
    model.eval()
    x = torch.from_numpy(x_new_scaled).to(device)
    z, mu, logvar = model.encoder(x)
    out = mu if return_type == "mu" else z
    return out.detach().cpu().numpy()

# total_columns = 50066
# features = np.random.rand(total_columns - 1)
# label = np.array([1])
# single_row_data = np.concatenate([label, features]).reshape(1, -1)
# df = pd.DataFrame(single_row_data)
# column_names = ['label'] + [f'f{i}' for i in range(1, total_columns)]
# df.columns = column_names
#
# print(df.head())

def vae_process(df):
    print(df.shape)
    input_dim = ckpt["dims"][0]
    X_new_scaled = preprocess_one_sample(df.iloc[:, 1:], scaler=scaler, input_dim=input_dim)
    mu = encode_one_sample(vae, X_new_scaled, device=device, return_type="mu")
    print("✅ mu shape:", mu.shape)
    mu = pd.DataFrame(mu)
    mu.index = df.index
    mu.columns = mu.columns.astype(str)

    return mu

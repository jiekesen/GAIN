from collections import OrderedDict  # 使用 OrderedDict 保持模型顺序

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEED = 3407
torch.manual_seed(SEED)
np.random.seed(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
torch.multiprocessing.set_sharing_strategy('file_system')


class ResidualMLP(nn.Module):
    def __init__(self, dim, hidden, drop=0.2):
        super().__init__()
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)
        self.bn1 = nn.BatchNorm1d(hidden)
        self.drop = nn.Dropout(drop)
        self.act = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        h = self.drop(self.act(self.bn1(self.fc1(x))))
        return self.act(x + self.fc2(h))


class MMOE(nn.Module):
    def __init__(self, input_dim, task_num, num_experts=6, expert_dim=256, tower_dims=(256, 128), drop=0.25):
        super().__init__()
        self.task_num = task_num
        self.num_experts = num_experts
        self.input_bn = nn.BatchNorm1d(input_dim)
        self.shared = nn.Sequential(nn.Linear(input_dim, expert_dim), nn.LeakyReLU(inplace=True))
        self.experts = nn.ModuleList([ResidualMLP(expert_dim, expert_dim, drop) for _ in range(num_experts)])
        self.gates = nn.ModuleList([nn.Linear(expert_dim, num_experts) for _ in range(task_num)])
        self.towers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(expert_dim, tower_dims[0]), nn.LeakyReLU(inplace=True), nn.Dropout(drop),
                nn.Linear(tower_dims[0], tower_dims[1]), nn.LeakyReLU(inplace=True), nn.Dropout(drop),
                nn.Linear(tower_dims[1], 1)
            ) for _ in range(task_num)
        ])

    def forward(self, x):
        x = self.input_bn(x)
        h = self.shared(x)
        expert_outs = torch.stack([E(h) for E in self.experts], dim=2)
        outs = []
        for t in range(self.task_num):
            w = F.softmax(self.gates[t](h), dim=-1)
            w = w.unsqueeze(-1)
            m = torch.bmm(expert_outs, w).squeeze(-1)
            y = self.towers[t](m).squeeze(-1)  #
            outs.append(y)
        return outs


class PCGrad(torch.optim.Optimizer):
    def __init__(self, optimizer):
        self._optim = optimizer

    @property
    def param_groups(self):
        return self._optim.param_groups

    def zero_grad(self):
        self._optim.zero_grad()

    def step(self):
        self._optim.step()

    def pc_backward(self, losses):
        grads = []
        shared = [p for g in self.param_groups for p in g['params'] if p.requires_grad]
        for L in losses:
            self.zero_grad()
            L.backward(retain_graph=True)
            grads.append([p.grad.detach().clone() if p.grad is not None else torch.zeros_like(p) for p in shared])
        for i in range(len(grads)):
            gi = grads[i]
            for j in range(len(grads)):
                if i == j: continue
                gj = grads[j]
                dot = sum((a * b).sum() for a, b in zip(gi, gj))
                if dot < 0:
                    norm = sum((b * b).sum() for b in gj) + 1e-12
                    gi = [a - (dot / norm) * b for a, b in zip(gi, gj)]
            grads[i] = gi
        self.zero_grad()
        for p_idx, p in enumerate(shared):
            p.grad = sum(g[p_idx] for g in grads) / len(grads)


class GradNorm:
    def __init__(self, model, alpha=0.12, lr=0.005):
        self.model = model
        self.alpha = alpha
        self.initial_losses = None
        self.lr = lr

    def update_weights(self, task_losses, task_weights):
        g_param = self.model.shared[0].weight
        grads = []
        for L in task_losses:
            g = torch.autograd.grad(L, g_param, retain_graph=True, allow_unused=True)[0]
            g_norm = torch.tensor(0.0, device=task_weights.device) if g is None else g.norm()
            grads.append(g_norm)
        grads = torch.stack([torch.nan_to_num(g, nan=0.0) for g in grads])
        losses = torch.stack(task_losses).detach()
        if self.initial_losses is None:
            self.initial_losses = losses.clone()
        loss_ratio = torch.clamp(losses / (self.initial_losses + 1e-8), 0.5, 2.0)
        mean_grad = grads.mean()
        targets = mean_grad * (loss_ratio ** self.alpha)
        with torch.no_grad():
            new_weights = task_weights - self.lr * (grads - targets)
            new_weights = torch.clamp(new_weights, 1e-3, 1.0)
            new_weights = new_weights / new_weights.sum()
        return new_weights


def masked_mse(pred, target, mask):
    if mask.any():
        loss = F.mse_loss(pred[mask], target[mask])
        return loss if not torch.isnan(loss) else torch.zeros([], requires_grad=True).to(pred.device)
    return torch.zeros([], requires_grad=True).to(pred.device)


def safe_pearson(a, b):
    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])



class PredictionDataset(Dataset):
    """
    """

    def __init__(self, X, index):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.index = np.array(index)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, i):
        return self.X[i], self.index[i]

def g_prediction(gene_data):

    # ==== 特征与标签列 ====
    label_cols = ['HD', 'PH', 'PL', 'TN', 'GP', 'SSR', 'TGW', 'GL', 'GW', 'Y']
    used_cols = [str(i) for i in range(1024)]

    task_num = len(label_cols)
    model = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_gzl = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_nn = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_wh = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_th = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_km = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_hz = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_hf = MMOE(input_dim=len(used_cols), task_num=task_num).to(device)

    base_optim = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)

    optimizer = PCGrad(base_optim)

    log_vars = nn.Parameter(torch.zeros(task_num, device=device))

    base_optim.add_param_group({"params": [log_vars]})

    scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
        base_optim, T_0=10, T_mult=2, eta_min=1e-5)

    gzl_path = "gs_g/gzl23_best_mmoe.pt"
    wh_path = "gs_g/wh23_best_mmoe.pt"
    nn_path = "gs_g/nn23_best_mmoe.pt"
    hf_path = "gs_g/hf23_best_mmoe.pt"
    hz_path = "gs_g/hz23_best_mmoe.pt"
    km_path = "gs_g/km23_best_mmoe.pt"
    th_path = "gs_g/th23_best_mmoe.pt"

    ckpt_gzl = torch.load(gzl_path, map_location=device, weights_only=False)
    model_gzl.load_state_dict(ckpt_gzl["model_state"])
    model_gzl.eval()
    y_scalers_gzl = ckpt_gzl["y_scalers"]
    x_scaler_gzl = ckpt_gzl["x_scaler"]

    ckpt_wh = torch.load(wh_path, map_location=device, weights_only=False)
    model_wh.load_state_dict(ckpt_wh["model_state"])
    model_wh.eval()
    y_scalers_wh = ckpt_wh["y_scalers"]
    x_scaler_wh = ckpt_wh["x_scaler"]

    ckpt_nn = torch.load(nn_path, map_location=device, weights_only=False)
    model_nn.load_state_dict(ckpt_nn["model_state"])
    model_nn.eval()
    y_scalers_nn = ckpt_nn["y_scalers"]
    x_scaler_nn = ckpt_nn["x_scaler"]

    ckpt_hf = torch.load(hf_path, map_location=device, weights_only=False)
    model_hf.load_state_dict(ckpt_hf["model_state"])
    model_hf.eval()
    y_scalers_hf = ckpt_hf["y_scalers"]
    x_scaler_hf = ckpt_hf["x_scaler"]

    ckpt_hz = torch.load(hz_path, map_location=device, weights_only=False)
    model_hz.load_state_dict(ckpt_hz["model_state"])
    model_hz.eval()
    y_scalers_hz = ckpt_hz["y_scalers"]
    x_scaler_hz = ckpt_hz["x_scaler"]

    ckpt_km = torch.load(km_path, map_location=device, weights_only=False)
    model_km.load_state_dict(ckpt_km["model_state"])
    model_km.eval()
    y_scalers_km = ckpt_km["y_scalers"]
    x_scaler_km = ckpt_km["x_scaler"]

    ckpt_th = torch.load(th_path, map_location=device, weights_only=False)
    model_th.load_state_dict(ckpt_th["model_state"])
    model_th.eval()
    y_scalers_th = ckpt_th["y_scalers"]
    x_scaler_th = ckpt_th["x_scaler"]

    # data_all = pd.read_csv("gene_example.csv", index_col=0)
    data_all = gene_data.copy()
    #
    index = pd.DataFrame(data_all).index.astype(str)

    X_val_gzl = x_scaler_gzl.transform(data_all).astype(np.float32)
    X_val_gzl = np.nan_to_num(X_val_gzl)

    X_val_wh = x_scaler_wh.transform(data_all).astype(np.float32)
    X_val_wh = np.nan_to_num(X_val_wh)

    X_val_th = x_scaler_th.transform(data_all).astype(np.float32)
    X_val_th = np.nan_to_num(X_val_th)

    X_val_hz = x_scaler_hz.transform(data_all).astype(np.float32)
    X_val_hz = np.nan_to_num(X_val_hz)

    X_val_nn = x_scaler_nn.transform(data_all).astype(np.float32)
    X_val_nn = np.nan_to_num(X_val_nn)

    X_val_km = x_scaler_km.transform(data_all).astype(np.float32)
    X_val_km = np.nan_to_num(X_val_km)

    X_val_hf = x_scaler_hf.transform(data_all).astype(np.float32)
    X_val_hf = np.nan_to_num(X_val_hf)



    # ====================================================================
    # 4. 初始化 Dataset 和 DataLoader
    # ====================================================================

    prediction_dataset = PredictionDataset(
        X=X_val_gzl,  # 传入经过缩放和 NaN 填充的数据
        index=index  # 传入样本索引
    )

    # 创建 DataLoader
    prediction_loader = DataLoader(
        prediction_dataset,
        batch_size=512,  # 保持与验证/训练时一致或根据内存调整
        shuffle=False,  # 预测时不能打乱顺序，必须是 False
        num_workers=4,  # 并行加载数据的工作进程数
        pin_memory=True  # 加速 GPU 传输
    )

    # =================================================================
    # 1. 定义模型配置和检查点路径
    # =================================================================

    model_configs = OrderedDict([
        ('gzl', gzl_path),
        ('wh', wh_path),
        ('nn', nn_path),
        ('hf', hf_path),
        ('hz', hz_path),
        ('km', km_path),
        ('th', th_path),
    ])

    # 将模型实例和对应的名称配对
    model_instances = {
        'gzl': model_gzl,
        'wh': model_wh,
        'nn': model_nn,
        'hf': model_hf,
        'hz': model_hz,
        'km': model_km,
        'th': model_th,
    }

    final_predictions_dict = {}

    # =================================================================
    # 2. 循环加载模型、预测和逆缩放
    # =================================================================

    for model_name, ckpt_path in model_configs.items():
        print(f"\n--- 正在处理模型: {model_name} ---")

        # 2.1 加载模型和缩放器
        try:

            current_model = model_instances[model_name]
            ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)

            # 加载模型状态
            current_model.load_state_dict(ckpt["model_state"])
            current_model.to(device)
            current_model.eval()

            # 加载缩放器
            y_scalers = ckpt["y_scalers"]

        except KeyError as e:
            continue
        except RuntimeError as e:
            continue

        # 2.2 推理阶段
        all_preds = []
        all_indices = []  # 只需要收集一次索引，但为安全起见每次都收集

        with torch.no_grad():
            for Xb, index_batch in prediction_loader:
                Xb = Xb.to(device)

                # 使用当前模型进行预测
                outs = current_model(Xb)
                preds = torch.stack(outs, dim=1)  # [B, task_num]

                all_preds.append(preds.cpu().numpy())
                all_indices.extend(index_batch)

        preds_array = np.concatenate(all_preds, axis=0)

        # 2.3 逆标准化和结果整理
        df_result = pd.DataFrame(index=all_indices)

        if y_scalers is not None:

            for t in range(len(label_cols)):
                preds_t = preds_array[:, t:t + 1]

                preds_array[:, t:t + 1] = y_scalers[t].inverse_transform(preds_t)
                df_result[label_cols[t]] = preds_array[:, t]
        else:
            for t in range(len(label_cols)):
                df_result[label_cols[t] + "_Scaled"] = preds_array[:, t]

        # 2.4 存储结果到字典
        final_predictions_dict[model_name] = df_result.astype(float)

    return final_predictions_dict


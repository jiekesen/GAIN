from fastapi import FastAPI, Query, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import duckdb
import pandas as pd
import json
import io

from gs_g import g_pre
from gs_ge import ge_pre
from data_vae import vae

app = FastAPI()

# --- 配置 CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = r"env.duckdb"
TABLE = "env_data"


# --- Pydantic 模型定义 (对应前端数据结构) ---

class Coordinates(BaseModel):
    lat: float
    lng: float


class DataPoint(BaseModel):
    day: int
    value: float  # 用户修改后的值（用于预测）
    originalValue: float  # 原始值


class PredictPayload(BaseModel):
    coordinates: Optional[Coordinates] = None
    useEnvironment: bool
    # Key 是环境因子名称 (e.g., "T2M_MAX"), Value 是数据点数组
    envData: Optional[Dict[str, List[DataPoint]]] = None


# --- 新增：数据格式化辅助函数 ---
def format_prediction_result(raw_result: dict) -> dict:
    """
    将嵌套结构: { "地点": { "因子": { "样本": 值 } } }
    转换为扁平结构: { "地点": [ { "sampleId": "s1", "HD": 10, "PH": 20 }, ... ] }
    """
    formatted = {}

    for location, factors_data in raw_result.items():
        # 1. 使用字典聚合每个样本的数据
        samples_map = {}

        for factor, samples in factors_data.items():
            for sample_id, value in samples.items():
                if sample_id not in samples_map:
                    samples_map[sample_id] = {"sampleId": sample_id}

                # 保留2位小数，避免前端看到 10.00000001
                samples_map[sample_id][factor] = round(value, 2)

        # 2. 转为列表
        rows = list(samples_map.values())

        # 3. (可选) 按 sampleId 简单排序，保证顺序稳定
        # 这里做一个简单的自然排序尝试
        try:
            rows.sort(key=lambda x: int(''.join(filter(str.isdigit, x["sampleId"]))))
        except:
            rows.sort(key=lambda x: x["sampleId"])

        formatted[location] = rows

    return formatted


# --- API 1: 获取环境数据 (GET) ---
@app.get("/api/climate")
def get_climate_data(
        lat: float = Query(..., description="Latitude"),
        lng: float = Query(..., description="Longitude")
):
    # --- 修改开始：严格最近邻模式 (Nearest Neighbor) ---

    # 1. 设置搜索半径
    # 你的经度间隔是 5 度，意味着最坏情况（两根经线正中间）离最近的点约 2.5 度。
    # 设置为 3 度，确保能覆盖到最近的那个点，解决“点不到数据”的问题。
    search_radius = 3

    # 2. 构造 SQL
    # 逻辑说明：
    # Step A (closest_loc): 在 3 度的大方框内，找出距离点击点 (lat, lng) 最近的【唯一】一个坐标。
    # Step B (Main Select): 用这个唯一的 (lat_k, lon_k) 去主表里把该站点所有的时序数据拿出来。
    sql = f"""
        WITH closest_loc AS (
            SELECT lat_k, lon_k,
                   -- 计算距离平方 (用于排序，不需要开根号)
                   POWER(lat_k - ?, 2) + POWER(lon_k - ?, 2) AS dist_sq
            FROM {TABLE}
            WHERE lat_k BETWEEN ? AND ? 
              AND lon_k BETWEEN ? AND ?
            -- 核心逻辑：按距离排序，取第一名
            ORDER BY dist_sq ASC
            LIMIT 1
        )
        SELECT t.env, t.value
        FROM {TABLE} t
        JOIN closest_loc c ON t.lat_k = c.lat_k AND t.lon_k = c.lon_k
        ORDER BY t.env, t.year, t.doy
        """

    # 3. 准备参数列表 (注意对应 SQL 中的 ? 顺序)
    # 参数顺序:
    # 1,2: 计算距离用的 lat, lng
    # 3,4: lat 范围 (min, max)
    # 5,6: lon 范围 (min, max)
    params = [
        lat, lng,
        lat - search_radius, lat + search_radius,
        lng - search_radius, lng + search_radius
    ]

    with duckdb.connect(DB_PATH, read_only=True) as con:
        df = con.execute(sql, params).df()

    # --- 修改结束 ---

    if df.empty:
        # 如果 3 度范围内（约330公里）都找不到点，说明真的是无人区/无数据区
        return {}

    out = {}
    for env, g in df.groupby("env", sort=False):
        out[env] = g["value"].tolist()
    return out

# --- API 2: 运行预测 (POST) ---
# 假设你已经导入了两个模型模块
# from app.models import g_pre, ge_pre

@app.post("/api/predict")
async def run_prediction(
        file: UploadFile = File(...),
        data: str = Form(...)
):
    # 1. 解析 JSON 数据
    try:
        payload_dict = json.loads(data)
        payload = PredictPayload(**payload_dict)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Invalid JSON data: {str(e)}")

    # 2. 读取 CSV 文件 (Genotype)
    try:
        contents = await file.read()
        df_genotype = pd.read_csv(io.BytesIO(contents))
        print(f"Genotype File Loaded. Shape: {df_genotype.shape}")
    except Exception as e:
        raise HTTPException(status_code=400, detail="Invalid CSV file")

    # 3. 处理环境数据逻辑
    final_env_data = {}

    if payload.useEnvironment:
        if not payload.envData:
            raise HTTPException(status_code=400, detail="useEnvironment is True but envData is missing")

        print("Processing Environmental Data...")

        # 1. 提取纯数值，构建字典
        # 结果形如: { "ALLSKY_SFC_PAR_TOT": [11.02, 11.2, ...], "T2M_MAX": [25.5, ...] }
        data_dict = {}
        days_count = 0

        for factor, points in payload.envData.items():
            # 只提取 value 字段
            data_dict[factor] = [p.value for p in points]
            days_count = len(points)  # 记录天数

        # 2. 创建 DataFrame
        df_env = pd.DataFrame(data_dict)

        # 3. 生成 YEAR 和 DOY 列
        # 注意：你需要定义一个起始日期。
        # 如果前端没有传起始日期，这里可以写死，或者用当前日期，或者用 2024-04-01 (匹配你的示例)
        start_date = "2024-04-01"

        # 生成日期序列
        date_range = pd.date_range(start=start_date, periods=days_count, freq='D')

        # 插入 YEAR 和 DOY 到最前面
        df_env.insert(0, 'DOY', date_range.dayofyear)
        df_env.insert(0, 'YEAR', date_range.year)

        # [可选] 确保列的顺序符合模型要求
        # 如果模型对列顺序敏感，可以强制重排
        desired_order = [
            "YEAR", "DOY",
            "ALLSKY_SFC_UVB", "ALLSKY_SFC_UVA", "ALLSKY_SFC_PAR_TOT",
            "RH2M", "WS2M", "PS", "GWETROOT", "GWETPROF",
            "WD2M", "PRECTOTCORR", "T2M_MAX", "T2M_MIN"
        ]
        # 只保留存在的列并排序，防止 KeyError
        existing_cols = [col for col in desired_order if col in df_env.columns]
        final_env_data = df_env[existing_cols]

        # [调试] 打印看看样子
        print("Generated Environment DataFrame:")
        print(final_env_data.head())

    else:
        print("Environment Data Ignored (useEnvironment=False)")
        final_env_data = None

    real_sample_ids = df_genotype.iloc[:, 0].values

    vae_result = vae.vae_process(df_genotype)

    if not isinstance(vae_result, pd.DataFrame):
        vae_result = pd.DataFrame(vae_result)

    vae_result.index = real_sample_ids
    vae_result.index.name = 'sampleId'

    # --- 4. 核心修改：根据开关调用不同的模型 ---
    try:
        if payload.useEnvironment:
            print(">>> Mode: Genotype + Environment Prediction (GE)")
            lat = round(payload.coordinates.lat, 2)
            raw_result = ge_pre.ge_prediction(vae_result, final_env_data, lat)
        else:
            print(">>> Mode: Genotype Only Prediction (G)")
            # 调用原有的 G 模型函数
            raw_result = g_pre.g_prediction(vae_result)

        # 5. 统一格式化输出
        formatted_data = format_prediction_result(raw_result)

        return {
            "status": "success",
            "message": "Prediction completed",
            "data": formatted_data
        }

    except Exception as e:
        import traceback
        traceback.print_exc()  # 在后端打印详细错误堆栈
        raise HTTPException(status_code=500, detail=f"Model execution failed: {str(e)}")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
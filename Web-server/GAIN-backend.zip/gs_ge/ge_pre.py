from collections import OrderedDict  # 使用 OrderedDict 保持模型顺序

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader

AGG_PLAN = {
    # 温度
    "Tmax": ["mean", "max", "min", "std"],
    "Tmin": ["mean", "max", "min", "std"],
    "DTR": ["mean", "max", "std"],
    "TSR": ["mean"],
    "MMR": ["mean"],
    "GDD": ["sum", "mean", "max"],
    "dGDD": ["sum", "mean"],
    # 水分
    "RH": ["mean", "min", "max", "std"],
    "PR": ["sum", "mean", "max"],
    "PRDTR": ["mean"],
    # 光照
    "DL_hours": ["mean", "max", "min"],
    "APAR": ["sum", "mean"],
    "UVA": ["sum", "mean"],
    "UVB": ["sum", "mean"],
    "PTT": ["sum", "mean"],
    "dPTT": ["sum", "mean"],
    "PTR": ["mean"],
    "PTD1": ["sum", "mean"],
    "PTD2": ["mean"],
    # 空气
    "PS_kPa": ["mean"],
    "WS2M_mps": ["mean", "max"],
    "WD": ["mean"],  # 精细可用圆统计
    # 土壤
    "SW": ["mean", "min", "max"],
    "SM": ["mean", "min", "max"],
}

# -------------------------
# MMOE 模型
# -------------------------
class ResidualMLP(nn.Module):
    def __init__(self, dim, hidden, drop=0.3):
        super().__init__()
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)
        self.bn1 = nn.BatchNorm1d(hidden)
        self.drop = nn.Dropout(drop)
        self.act = nn.LeakyReLU(0.1)

    def forward(self, x):
        h = self.act(self.bn1(self.fc1(x)))
        h = self.drop(h)
        return self.act(x + self.fc2(h))


class MyMMOE(nn.Module):
    def __init__(self, input_dim, task_num, num_experts=6, expert_dim=256, tower_dims=(256, 128), drop=0.3):
        super().__init__()
        self.task_num = task_num
        self.input_bn = nn.BatchNorm1d(input_dim)
        self.shared = nn.Sequential(
            nn.Linear(input_dim, expert_dim),
            nn.LeakyReLU()
        )
        self.experts = nn.ModuleList([ResidualMLP(expert_dim, expert_dim, drop) for _ in range(num_experts)])
        self.gates = nn.ModuleList([nn.Linear(expert_dim, num_experts) for _ in range(task_num)])
        self.towers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(expert_dim, tower_dims[0]), nn.LeakyReLU(), nn.Dropout(drop),
                nn.Linear(tower_dims[0], tower_dims[1]), nn.LeakyReLU(), nn.Dropout(drop),
                nn.Linear(tower_dims[1], 1)
            ) for _ in range(task_num)
        ])

    def forward(self, x):
        x = torch.nan_to_num(x)
        x = self.input_bn(x)
        h = self.shared(x)
        expert_outs = torch.stack([E(h) for E in self.experts], dim=2)
        outputs = []
        for t in range(self.task_num):
            g = F.softmax(self.gates[t](h), dim=-1).unsqueeze(-1)
            m = torch.bmm(expert_outs, g).squeeze(-1)
            outputs.append(self.towers[t](m).squeeze(-1))
        return outputs


# -------------------------
# GradNorm
# -------------------------
class GradNorm:
    def __init__(self, model, alpha=0.12, lr=0.005):
        self.model = model
        self.alpha = alpha
        self.initial_losses = None
        self.lr = lr

    def update_weights(self, task_losses, task_weights):
        g_param = self.model.shared[0].weight
        grads = []
        for L in task_losses:
            g = torch.autograd.grad(L, g_param, retain_graph=True, allow_unused=True)[0]
            g_norm = torch.tensor(0.0, device=task_weights.device) if g is None else g.norm()
            grads.append(g_norm)
        grads = torch.stack([torch.nan_to_num(g, nan=0.0) for g in grads])
        losses = torch.stack(task_losses).detach()
        if self.initial_losses is None:
            self.initial_losses = losses.clone()
        loss_ratio = torch.clamp(losses / (self.initial_losses + 1e-8), 0.5, 2.0)
        mean_grad = grads.mean()
        targets = mean_grad * (loss_ratio ** self.alpha)
        with torch.no_grad():
            new_weights = task_weights - self.lr * (grads - targets)
            new_weights = torch.clamp(new_weights, 1e-3, 1.0)
            new_weights = new_weights / new_weights.sum()
        return new_weights

class PredictionDataset(Dataset):
    """
    """
    def __init__(self, X, index):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.index = np.array(index)
    def __len__(self):
        return len(self.X)
    def __getitem__(self, i):
        return self.X[i], self.index[i]

# -------------------------
# 工具函数
# -------------------------
def masked_mse(pred, target, mask):
    if mask.any():
        loss = F.mse_loss(pred[mask], target[mask])
        return loss if not torch.isnan(loss) else torch.zeros([], requires_grad=True).to(pred.device)
    return torch.zeros([], requires_grad=True).to(pred.device)


def safe_pearson(a, b):
    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def aggregate_slice(df_slice, prefix):
    out = {}
    out[f"{prefix}_ndays"] = len(df_slice)
    for col, funcs in AGG_PLAN.items():
        if col not in df_slice.columns:
            continue
        s = df_slice[col]
        for fn in funcs:
            if fn == "sum":
                val = s.sum(min_count=1)
            elif fn == "mean":
                val = s.mean()
            elif fn == "max":
                val = s.max()
            elif fn == "min":
                val = s.min()
            elif fn == "std":
                val = s.std(ddof=0)
            else:
                continue
            out[f"{prefix}_{col}_{fn}"] = val
    return out


def predict_with_model(model, X_np, y_scalers, index,
                       device, batch_size=512, num_workers=4):
    loader = DataLoader(
        PredictionDataset(X=X_np, index=index),
        batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )

    model.eval()
    all_preds, all_index = [], []

    with torch.no_grad():
        for Xb, idx in loader:
            Xb = Xb.to(device, non_blocking=True)
            outs = model(torch.nan_to_num(Xb))

            if isinstance(outs, (list, tuple)):
                preds_batch = torch.stack(outs, dim=1)
            else:
                preds_batch = outs

            all_preds.append(preds_batch.cpu().numpy())
            all_index.append(np.array(idx))  # idx 是 list/array，转 np

    preds = np.concatenate(all_preds, axis=0)
    idx_all = np.concatenate(all_index, axis=0)

    # 逆缩放：y_scalers 通常是 list，每个 task 一个 scaler
    preds_inv = preds.copy()
    if isinstance(y_scalers, (list, tuple)):
        for t in range(preds.shape[1]):
            preds_inv[:, t] = y_scalers[t].inverse_transform(preds[:, [t]]).ravel()
    else:
        preds_inv = y_scalers.inverse_transform(preds)

    return preds_inv, idx_all

def ge_prediction(gene_data, env_data, lat):
    ### env
    day_data = pd.read_csv("gs_ge/23day_hebing.csv")  ##  这个文件写死，后面代码一直需要

    df = env_data

    latitude = lat

    TBASE = 10.0  # °C

    phi = np.radians(latitude)
    df["declination"] = np.radians(23.45) * np.sin(2 * np.pi * (df["DOY"] - 81) / 365)

    # ===== 计算日落时角 ωs =====
    # ωs = arccos(-tanφ * tanδ)
    df["omega_s"] = np.arccos(-np.tan(phi) * np.tan(df["declination"]))

    # ===== 计算日照时长 N (小时) =====
    # N = 24/π * ωs
    df["DL_hours"] = 24 / np.pi * df["omega_s"]

    if "DATE" not in df.columns:
        df["DATE"] = pd.to_datetime(df["YEAR"].astype(str) + df["DOY"].astype(str), format="%Y%j")
    else:
        df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")

    # 将缺失值 -999 转为 NaN
    df.replace(-999, np.nan, inplace=True)

    # ==== 原始量重命名（便于计算/对齐论文缩写）====
    df["Tmax"] = df["T2M_MAX"]
    df["Tmin"] = df["T2M_MIN"]
    df["RH"] = df["RH2M"]
    df["PR"] = df["PRECTOTCORR"]
    df["PS_kPa"] = df["PS"]
    df["WS2M_mps"] = df["WS2M"]
    df["WD"] = df["WD2M"]
    df["SW"] = df["GWETROOT"]
    df["SM"] = df["GWETPROF"]
    df["APAR"] = df["ALLSKY_SFC_PAR_TOT"]
    df["UVA"] = df["ALLSKY_SFC_UVA"]
    df["UVB"] = df["ALLSKY_SFC_UVB"]

    # ==== 温度类（7）====
    df["DTR"] = df["Tmax"] - df["Tmin"]  # Tmax - Tmin
    df["TSR"] = df["Tmax"] ** 2 - df["Tmin"] ** 2  # Tmax^2 - Tmin^2
    df["MMR"] = df["Tmin"] / df["Tmax"]  # Tmin / Tmax
    avgT = (df["Tmax"] + df["Tmin"]) / 2.0
    df["GDD"] = (avgT - TBASE).clip(lower=0)  # max(0, avgT - Tbase)
    df["dGDD"] = df["GDD"].diff().abs()  # |GDD_n - GDD_{n-1}|

    # ==== 光照类（9）====                                       # 有晴空PAR时填入
    df["PTT"] = df["GDD"] * df["DL_hours"]
    df["dPTT"] = df["PTT"].diff().abs()
    df["PTR"] = df["GDD"] / df["DL_hours"].replace(0, np.nan)
    df["PTD1"] = df["DTR"] * df["DL_hours"]
    df["PTD2"] = df["DTR"] / df["DL_hours"].replace(0, np.nan)

    # ==== 水分类（3）====
    df["PRDTR"] = df["PR"] / df["DTR"].replace(0, np.nan)

    # ==== 数值清理（避免 inf）====
    for c in ["MMR", "PTR", "PTD2", "PRDTR"]:
        df.loc[~np.isfinite(df[c]), c] = np.nan

    # ==== 输出列 ====
    cols_out = [
        "DATE",
        # 温度
        "Tmax", "Tmin", "DTR", "TSR", "MMR", "GDD", "dGDD",
        # 水分
        "RH", "PR", "PRDTR",
        # 光照
        "DL_hours", "APAR", "UVA", "UVB", "PTT", "dPTT", "PTR", "PTD1", "PTD2",
        # 空气
        "PS_kPa", "WS2M_mps", "WD",
        # 土壤
        "SW", "SM",
        # 可留存原始定位信息
        "YEAR", "DOY"
    ]

    df_env = df.drop(columns=["DATE", "YEAR", "DOY"])

    daily = df_env

    # 没有日期列 => 加一个简单的日序
    # daily["DAY_INDEX"] = np.arange(1, len(daily) + 1)

    # 每个变量使用的聚合计划（可按需增删）


    # (A) 全生长季聚合（一行）
    season_row = aggregate_slice(daily, prefix="SEASON")
    season_df = pd.DataFrame([season_row])
    season_df = season_df.drop(columns=["SEASON_ndays"])

    season_df.insert(0, "label", "pre")
    df = pd.concat([season_df, day_data], axis=0)
    season_df_ori = season_df.drop(columns=['label'])
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(df.iloc[:, 1:])
    features_scaled = pd.DataFrame(features_scaled)

    coname = list(season_df_ori.columns)
    features_scaled = features_scaled.iloc[[0], :]
    features_scaled.columns = coname

    data_all = gene_data
    # 增加索引
    sample_ids = data_all.index

    features_scaled_pre = pd.concat([features_scaled] * data_all.shape[0], ignore_index=True)
    pre_data = pd.concat([data_all.reset_index(drop=True),
                          features_scaled_pre.reset_index(drop=True)], axis=1)

    ### model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    SEED = 3407
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False
    torch.multiprocessing.set_sharing_strategy('file_system')
    USE_PCGRAD = False
    task_num = 1

    used_cols = [c for c in pre_data.columns]


    hd_path = "gs_ge/23_hd_env_best_mmoe.pt"
    ph_path = "gs_ge/23_ph_env_best_mmoe.pt"
    gl_path = "gs_ge/23_gl_env_best_mmoe.pt"
    gw_path = "gs_ge/23_gw_env_best_mmoe.pt"
    tn_path = "gs_ge/23_suishu_env_best_mmoe.pt"
    pl_path = "gs_ge/23_suichang_env_best_mmoe.pt"
    gp_path = "gs_ge/23_suilishu_env_best_mmoe.pt"
    y_path  = "gs_ge/23_y_env_best_mmoe.pt"
    tgw_path = "gs_ge/23_tkw_env_best_mmoe.pt"
    ssr_path = "gs_ge/23_ssr_env_best_mmoe.pt"

    model = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_hd = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_ph = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_gl = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_gw = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_ssr = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_tgw = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_y = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_tn = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_gp = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)
    model_pl = MyMMOE(input_dim=len(used_cols), task_num=task_num).to(device)

    ckpt_hd = torch.load(hd_path, map_location=device, weights_only=False)
    model_hd.load_state_dict(ckpt_hd["model_state"])
    model_hd.eval()
    y_scalers_hd = ckpt_hd["y_scalers"]
    x_scaler_hd = ckpt_hd["x_scaler"]

    ckpt_ph = torch.load(ph_path, map_location=device, weights_only=False)
    model_ph.load_state_dict(ckpt_ph["model_state"])
    model_ph.eval()
    y_scalers_ph = ckpt_ph["y_scalers"]
    x_scaler_ph = ckpt_ph["x_scaler"]

    ckpt_gl = torch.load(gl_path, map_location=device, weights_only=False)
    model_gl.load_state_dict(ckpt_gl["model_state"])
    model_gl.eval()
    y_scalers_gl = ckpt_gl["y_scalers"]
    x_scaler_gl = ckpt_gl["x_scaler"]

    ckpt_gw = torch.load(gw_path, map_location=device, weights_only=False)
    model_gw.load_state_dict(ckpt_gw["model_state"])
    model_gw.eval()
    y_scalers_gw = ckpt_gw["y_scalers"]
    x_scaler_gw = ckpt_gw["x_scaler"]

    ckpt_tn = torch.load(tn_path, map_location=device, weights_only=False)
    model_tn.load_state_dict(ckpt_tn["model_state"])
    model_tn.eval()
    y_scalers_tn = ckpt_tn["y_scalers"]
    x_scaler_tn = ckpt_tn["x_scaler"]

    ckpt_pl = torch.load(pl_path, map_location=device, weights_only=False)
    model_pl.load_state_dict(ckpt_pl["model_state"])
    model_pl.eval()
    y_scalers_pl = ckpt_pl["y_scalers"]
    x_scaler_pl = ckpt_pl["x_scaler"]

    ckpt_gp = torch.load(gp_path, map_location=device, weights_only=False)
    model_gp.load_state_dict(ckpt_gp["model_state"])
    model_gp.eval()
    y_scalers_gp = ckpt_gp["y_scalers"]
    x_scaler_gp = ckpt_gp["x_scaler"]

    ckpt_y = torch.load(y_path, map_location=device, weights_only=False)
    model_y.load_state_dict(ckpt_y["model_state"])
    model_y.eval()
    y_scalers_y = ckpt_y["y_scalers"]
    x_scaler_y = ckpt_y["x_scaler"]

    ckpt_tgw = torch.load(tgw_path, map_location=device, weights_only=False)
    model_tgw.load_state_dict(ckpt_tgw["model_state"])
    model_tgw.eval()
    y_scalers_tgw = ckpt_tgw["y_scalers"]
    x_scaler_tgw = ckpt_tgw["x_scaler"]

    ckpt_ssr = torch.load(ssr_path, map_location=device, weights_only=False)
    model_ssr.load_state_dict(ckpt_ssr["model_state"])
    model_ssr.eval()
    y_scalers_ssr = ckpt_ssr["y_scalers"]
    x_scaler_ssr = ckpt_ssr["x_scaler"]

    base_optim = optim.AdamW(model.parameters(), lr=2e-4, weight_decay=1e-5)
    log_vars = nn.Parameter(torch.zeros(task_num).to(device))
    base_optim.add_param_group({"params": [log_vars]})

    optimizer = base_optim
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(base_optim, T_0=10, T_mult=2)
    task_weights = torch.ones(task_num, device=device) / task_num
    gradnorm = GradNorm(model)

    best_mean_corr = -1

    index = pd.DataFrame(pre_data).index.astype(str)

    print(pre_data.columns)
    X_val_hd = x_scaler_hd.transform(pre_data).astype(np.float32)
    X_val_hd = np.nan_to_num(X_val_hd)

    X_val_ph = x_scaler_ph.transform(pre_data).astype(np.float32)
    X_val_ph = np.nan_to_num(X_val_ph)

    X_val_gl = x_scaler_gl.transform(pre_data).astype(np.float32)
    X_val_gl = np.nan_to_num(X_val_gl)

    X_val_gw = x_scaler_gw.transform(pre_data).astype(np.float32)
    X_val_gw = np.nan_to_num(X_val_gw)

    X_val_pl = x_scaler_pl.transform(pre_data).astype(np.float32)
    X_val_pl = np.nan_to_num(X_val_pl)

    X_val_tn = x_scaler_tn.transform(pre_data).astype(np.float32)
    X_val_tn = np.nan_to_num(X_val_tn)

    X_val_gp = x_scaler_gp.transform(pre_data).astype(np.float32)
    X_val_gp = np.nan_to_num(X_val_gp)

    X_val_y = x_scaler_y.transform(pre_data).astype(np.float32)
    X_val_y = np.nan_to_num(X_val_y)

    X_val_ssr = x_scaler_ssr.transform(pre_data).astype(np.float32)
    X_val_ssr = np.nan_to_num(X_val_ssr)

    X_val_tgw = x_scaler_tgw.transform(pre_data).astype(np.float32)
    X_val_tgw = np.nan_to_num(X_val_tgw)


    # ====================================================================
    # 4. 初始化 Dataset 和 DataLoader
    # ====================================================================
    prediction_dataset = DataLoader(PredictionDataset(X=X_val_hd, index=index),
                                    batch_size=512,
                                    shuffle=False,
                                    num_workers=4,
                                    pin_memory=True)

    X_inputs = {
        "hd": X_val_hd,
        "ph": X_val_ph,
        "gl": X_val_gl,
        "gw": X_val_gw,
        "pl": X_val_pl,
        "tn": X_val_tn,
        "gp": X_val_gp,
        "ssr": X_val_ssr,
        "y": X_val_y,
        "tgw": X_val_tgw,
    }

    model_configs = OrderedDict([
        ('hd', hd_path),
        ('ph', ph_path),
        ('gl', gl_path),
        ('gw', gw_path),
        ('pl', pl_path),
        ('tn', tn_path),
        ('gp', gp_path),
        ('ssr', ssr_path),
        ('y', y_path),
        ('tgw', tgw_path),
    ])

    # 将模型实例和对应的名称配对
    model_instances = {
        'hd': model_hd,
        'ph': model_ph,
        'gl': model_gl,
        'gw': model_gw,
        'pl': model_pl,
        'tn': model_tn,
        'gp': model_gp,
        'ssr': model_ssr,
        'y': model_y,
        'tgw': model_tgw,
    }

    y_scalers_map = {
        "hd": y_scalers_hd,
        "ph": y_scalers_ph,
        "gl": y_scalers_gl,
        "gw": y_scalers_gw,
        "pl": y_scalers_pl,
        "tn": y_scalers_tn,
        "gp": y_scalers_gp,
        "ssr": y_scalers_ssr,
        "y": y_scalers_y,
        "tgw": y_scalers_tgw,
    }

    final_predictions_dict = {}

    for name, mdl in model_instances.items():
        X_np = X_inputs[name]
        ys = y_scalers_map[name]

        preds_inv, idx_all = predict_with_model(
            model=mdl, X_np=X_np, y_scalers=ys, index=index,
            device=device, batch_size=512, num_workers=4
        )

        # 存成 DataFrame 更方便后处理
        cols = [f"{name}" for i in range(preds_inv.shape[1])]
        pred_df = pd.DataFrame(preds_inv, columns=cols)

        pred_df.index = sample_ids

        final_predictions_dict[name] = pred_df.astype(float)

    return final_predictions_dict
#
# if __name__ == "__main__":
#     gene = pd.read_csv("data_vae_all.csv", index_col=0)
#     env = pd.read_csv("24_wh_env.csv")
#
#     result = ge_prediction(gene, env)
#     print(result)
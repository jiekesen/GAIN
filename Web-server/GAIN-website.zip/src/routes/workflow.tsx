import React from 'react';
// import { createFileRoute, Link } from '@tanstack/react-router'; // Uncomment for TanStack Router
import {ArrowRight, Binary, Cpu, Database, MousePointerClick, Sprout} from 'lucide-react';
import {createFileRoute} from "@tanstack/react-router";

// Uncomment for TanStack Router
export const Route = createFileRoute('/workflow')({
    component: RouteComponent,
})

// Export default for preview rendering
function RouteComponent() {
    return (
        // 修改点：min-h-full 改为 h-full
        // 这样容器高度会被限制在父级容器的可视区域内，溢出内容才会触发 overflow-y-auto
        <div
            className="h-full bg-slate-950 text-slate-200 font-sans selection:bg-emerald-500/30 p-6 md:p-12 overflow-y-auto custom-scrollbar">
            <div className="max-w-5xl mx-auto space-y-16 pb-20">

                {/* Header */}
                <div className="text-center space-y-4 animate-in slide-in-from-top-4 fade-in duration-700">
                    <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
                        <span
                            className="text-transparent bg-clip-text bg-linear-to-r from-emerald-400 to-blue-500">GAIN</span>
                    </h1>
                    <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                        Our platform integrates high-throughput genomic data with environmental data using deep learning
                        architectures.
                    </p>
                </div>

                {/* Workflow Steps Container */}
                <div className="grid gap-12 relative">
                    {/* Connecting Line (Desktop Only) */}
                    <div
                        className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-linear-to-b from-emerald-500/0 via-emerald-500/20 to-emerald-500/0 -translate-x-1/2"/>

                    {/* Step 1: Data Collection */}
                    <WorkflowStep
                        number="01"
                        title="Multi-Modal Data Ingestion"
                        description="We aggregate two distinct data streams: genomic sequences (SNPs) from VCF files and historical environmental logs matched to specific geolocations."
                        icon={<Database size={24} className="text-blue-400"/>}
                        side="left"
                    />

                    {/* Step 2: Feature Engineering */}
                    <WorkflowStep
                        number="02"
                        title="Tensor Transformation"
                        description="The raw data are processed and transformed into input tensors. Specifically, genotypic data are embedded into feature representations through an encoder, while environmental data are concatenated with the latent features to construct a G×E matrix."
                        icon={<Binary size={24} className="text-purple-400"/>}
                        side="right"
                    />
                    {/* Step 2: Feature Engineering */}
                    <WorkflowStep
                        number="03"
                        title="Note"
                        description="You can upload a genotypic file to perform prediction analysis. A sample genotypic file is available by clicking Example.csv. After clicking the Environment button, you can select the locations of interest by clicking the green highlighted areas on the map to conduct G×E prediction. Once confirmed, the corresponding environmental data will be automatically retrieved and loaded into the model."
                        icon={<MousePointerClick size={24} className="text-purple-400"/>}
                        side="left"
                    />

                    {/* Step 3: AI Model */}
                    <WorkflowStep
                        number="04"
                        title="Deep Learning Architecture"
                        description="GAIN adopts a network architecture that combines a VAE with multi-task learning. The VAE is used to learn low-dimensional latent representations with biological relevance from genomic data, while the multi-task network builds upon these representations to model G×E interactions and trait co-regulation, enabling joint prediction of phenotypes across multiple environments and traits."
                        icon={<Cpu size={24} className="text-orange-400"/>}
                        side="right"
                    />


                    {/* Step 4: Prediction */}
                    <WorkflowStep
                        number="05"
                        title="Phenotype prediction"
                        description="The model provides predictions for rice agronomic traits, including heading date (HD), plant height (PH), panicle length (PL), tiller number (TN), grains per panicle (GP), seed-setting rate (SST), grain length (GL), grain width (GW), thousand-grain weight (TGW), and yield (Y)."
                        icon={<Sprout size={24} className="text-emerald-400"/>}
                        side="left"
                    />
                </div>

                {/* Call to Action */}
                <div className="text-center pt-16">
                    <a
                        href="/"
                        className="inline-flex items-center gap-2 px-8 py-4 bg-linear-to-r from-emerald-600 to-blue-600 rounded-full font-bold text-white hover:shadow-lg hover:shadow-emerald-900/20 hover:scale-105 transition-all group"
                    >
                        Start Prediction <ArrowRight size={20}
                                                     className="group-hover:translate-x-1 transition-transform"/>
                    </a>
                </div>

            </div>
        </div>
    )
}

// --- Helper Components ---

interface WorkflowStepProps {
    number: string;
    title: string;
    description: string;
    icon: React.ReactNode;
    side: 'left' | 'right';
    children?: React.ReactNode;
}

const WorkflowStep = ({number, title, description, icon, side, children}: WorkflowStepProps) => {
    const isLeft = side === 'left';

    return (
        <div
            className={`flex flex-col md:flex-row items-center gap-8 md:gap-16 ${isLeft ? '' : 'md:flex-row-reverse'}`}>
            {/* Text Side */}
            <div className={`flex-1 text-center ${isLeft ? 'md:text-right' : 'md:text-left'} w-full`}>
                <div
                    className={`inline-flex items-center justify-center w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 mb-4 shadow-xl ${isLeft ? 'md:ml-auto' : 'md:mr-auto'}`}>
                    {icon}
                </div>
                <h3 className="text-2xl font-bold text-slate-100 mb-3 flex items-center gap-2 justify-center md:justify-start">
                    {/* Mobile Number Layout */}
                    <span className="md:hidden text-emerald-500/50 font-mono text-sm">#{number}</span>
                    {/* Desktop Number Layout depends on flex direction, handled below in title content */}
                    {isLeft ? (
                        <>
                            {title}
                            <span
                                className="hidden md:inline text-emerald-500/50 font-mono text-lg ml-2">#{number}</span>
                        </>
                    ) : (
                        <>
                            <span
                                className="hidden md:inline text-emerald-500/50 font-mono text-lg mr-2">#{number}</span>
                            {title}
                        </>
                    )}
                </h3>
                <p className="text-slate-400 leading-relaxed text-sm md:text-base text-justify">
                    {description}
                </p>
                {children}
            </div>

            {/* Visual Side (Timeline Node - Desktop Only) */}
            <div className="relative flex-none hidden md:flex items-center justify-center w-12">
                <div
                    className="w-4 h-4 rounded-full bg-slate-950 border-2 border-emerald-500 z-10 shadow-[0_0_15px_rgba(16,185,129,0.5)] relative">
                    <div className="absolute inset-0 bg-emerald-500 animate-ping opacity-20 rounded-full"></div>
                </div>
            </div>

            {/* Spacer for layout balance */}
            <div className="flex-1 hidden md:block"></div>
        </div>
    )
}

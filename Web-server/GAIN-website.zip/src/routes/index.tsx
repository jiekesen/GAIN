import {createFileRoute} from '@tanstack/react-router';
import {ModelConsole} from '../components/ModelConsole';
import {EnvDataModal} from '../components/EnvDataModal';
import {RiceGeoMap} from "@/components/RiceGeoMap.tsx";
import {Server, Zap} from 'lucide-react';
import {AnalysisResultModal} from "@/components/AnalysisResultModal.tsx"; // 引入图标增强视觉

export const Route = createFileRoute('/')({
    component: HomePage,
})

function HomePage() {
    return (
        // 1. 全局容器：使用 Flex 布局，增加 p-4 和 gap-4 来制造“呼吸感”
        // bg-background (Navy-950) 作为底色，透过缝隙显示出来
        <div className="h-screen w-full flex bg-background p-4 gap-4 overflow-hidden font-sans text-foreground">

            {/* --- LEFT BLOCK: Map & Info --- */}
            {/* 增加 rounded-2xl 和 border-border 打造玻璃卡片感 */}
            <div className="flex-1 relative rounded-2xl overflow-hidden border border-border shadow-2xl bg-navy-900/50">

                {/* 地图组件填满容器 */}
                <div className="absolute inset-0 z-0">
                    <RiceGeoMap/>
                </div>

                {/* 顶部装饰：可选的渐变遮罩，防止地图过亮干扰文字 */}
                <div
                    className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-navy-950/80 to-transparent pointer-events-none z-10"/>

                {/* 底部悬浮信息栏 (Workflow Principle) */}
                {/* 修改：
                   - bottom-6 -> bottom-8 (稍微抬高)
                   - rounded-xl -> rounded-2xl (更圆润)
                   - bg-navy-900/80 -> bg-navy-900/60 + backdrop-blur-xl (更通透)
                */}
                <div className="absolute bottom-6 left-6 right-6 z-10">
                    <div
                        className="bg-navy-900/70 backdrop-blur-xl border border-border rounded-2xl p-5 flex items-center justify-between shadow-lg shadow-black/20">

                        {/* 左侧：标题与状态 */}
                        <div className="flex flex-col gap-1">
                            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 tracking-wide">
                                <Zap className="w-4 h-4 text-brand fill-brand/20"/>
                                <span>WORKFLOW STATUS</span>
                            </h3>
                            <div className="text-xs text-slate-400 font-medium pl-6">
                                System ready for genomics data integration & simulation.
                            </div>
                        </div>

                        {/* 右侧：指标状态 (使用胶囊样式) */}
                        <div className="flex gap-4">
                            <div
                                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-navy-950/50 border border-border">
                                <span className="relative flex h-2 w-2">
                                  <span
                                      className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                </span>
                                <span className="text-[10px] font-mono text-slate-300">API CONNECTED</span>
                            </div>

                            <div
                                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-navy-950/50 border border-border">
                                <Server className="w-3 h-3 text-brand"/>
                                <span className="text-[10px] font-mono text-slate-300">GPU CLUSTER: READY</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* --- RIGHT BLOCK: Console --- */}
            {/* 这里包一层 div 来控制圆角和阴影，
               注意：ModelConsole 内部可能需要把 w-[400px] 改为 w-full，或者在这里强制 w-[400px]
            */}
            <div className="w-[400px] flex-none rounded-2xl overflow-hidden border border-border shadow-2xl relative">
                <ModelConsole/>
            </div>

            {/* --- MODAL --- */}
            <EnvDataModal/>

            <AnalysisResultModal />

        </div>
    );
}
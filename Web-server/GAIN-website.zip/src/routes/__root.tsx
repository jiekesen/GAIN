import {createRootRoute, Outlet} from '@tanstack/react-router';
import {Navbar} from "../components/Navbar.tsx";
import {Toaster} from "sonner";

export const Route = createRootRoute({
    component: RootComponent,
});

function RootComponent() {
    return (
        // 1. 全局容器
        // - bg-background: 对应 CSS 中的 #020408 (Navy-950)
        // - text-foreground: 对应 CSS 中的 #F8FAFC (Slate-50)
        // - selection:... : 选中文字时显示“品牌青背景 + 深色文字”，极其醒目
        <div
            className="h-screen w-full flex flex-col bg-background text-foreground font-sans selection:bg-brand selection:text-navy-950 overflow-hidden"
        >
            {/* 2. Toaster 配置
                使用 theme="dark" 强制深色模式
                richColors 开启多彩状态（成功绿、失败红）
            */}
            <Toaster theme="dark" richColors closeButton position="top-center"/>

            {/* Navbar
               建议检查 Navbar 组件内部，确保它使用了 border-border 和 bg-navy-900/80 backdrop-blur
            */}
                <Navbar/>
            {/* 3. 主内容区
                min-h-0 是 Flex 布局中防止子元素溢出滚动失效的关键
            */}
            <main className="flex-1 flex flex-col min-h-0 relative overflow-hidden">
                <Outlet/>
            </main>

            {/* 4. Footer：极简悬浮感 */}
            {/* - border-border: 使用定义好的玻璃边框
               - bg-navy-900/30 + backdrop-blur: 产生磨砂玻璃效果，透过底部若隐若现
            */}
            <footer
                className="shrink-0 border-t border-border bg-navy-900/30 backdrop-blur-md py-2 text-center text-[10px] text-muted-foreground z-50">
                <div className="w-full px-6 flex justify-between items-center h-full">
                    <p className="font-mono tracking-tight opacity-70">
                        © 2025 RiceG×E Predictor Platform
                    </p>
                </div>
            </footer>
        </div>
    );
}
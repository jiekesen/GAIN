import {Dna, Download, FileCode, Globe, Info, Map, Terminal} from 'lucide-react';
import {createFileRoute} from "@tanstack/react-router";

export const Route = createFileRoute('/example')({
    component: RouteComponent,
})

function RouteComponent() {
    return (
        <div
            className="min-h-full bg-slate-950 text-slate-200 font-sans selection:bg-emerald-500/30 p-6 md:p-12 overflow-y-auto custom-scrollbar relative">

            {/* 背景装饰 (Background Gradients) */}
            <div
                className="absolute top-0 left-0 w-full h-96 bg-linear-to-b from-emerald-900/10 to-transparent pointer-events-none"/>
            <div
                className="absolute top-20 right-20 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"/>

            <div className="max-w-5xl mx-auto space-y-10 pb-20 relative z-10">
                {/* Header Section */}

                <div className="text-center space-y-4 animate-in slide-in-from-top-4 fade-in duration-700">
                    <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
                        Sample Datasets
                    </h1>
                    <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                        Explore the data structure specifications required for the GAIN model.
                    </p>
                </div>

                {/* Grid Layout for Main Content */}
                <div className="grid grid-cols-1 gap-8">

                    {/* Card 1: Genotypic Data */}
                    <div
                        className="group bg-slate-900/50 backdrop-blur-sm border border-white/5 rounded-2xl overflow-hidden hover:border-emerald-500/30 transition-all duration-300">
                        <div className="p-6 md:p-8 space-y-6">

                            {/* Card Header */}
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-4">
                                    <div
                                        className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
                                        <Dna size={28}/>
                                    </div>
                                    <div>
                                        <h2 className="text-xl font-bold text-white">Genotypic Data (SNP)</h2>
                                        <p className="text-sm text-slate-500">Supported Format: CSV</p>
                                    </div>
                                </div>
                                {/* Download Button styled as a primary action */}
                                <button
                                    className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-medium transition-all shadow-lg shadow-emerald-900/20 active:scale-95 text-sm">
                                    <Download size={18}/>
                                    <a
                                        href="/assets/gene_example.csv"
                                        download="gene_example.csv"
                                    >
                                        Download Sample .csv
                                    </a>
                                </button>
                            </div>

                            <hr className="border-white/5"/>

                            {/* Content: CSV Requirements */}
                            <div className="space-y-4">
                                <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                                    <Info size={14} className="text-emerald-500"/> Data Requirements
                                </h3>
                                <div
                                    className="bg-slate-950/50 border border-white/5 rounded-lg p-4 text-sm text-slate-300 leading-relaxed">
                                    <p>
                                        Please upload a CSV file. The structure must strictly follow:
                                    </p>
                                    <ul className="list-disc list-inside mt-2 space-y-1 text-slate-400 ml-1">
                                        <li><span className="text-slate-200 font-medium">Column 1:</span> Sample ID</li>
                                        <li><span
                                            className="text-slate-200 font-medium">Columns 2 - 50,066:</span> Numerical
                                            SNP features (Total <span
                                                className="text-emerald-400 font-mono font-bold">50,065</span> features)
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            {/* Content: PLINK Conversion */}
                            <div className="space-y-4">
                                <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                                    <Terminal size={14} className="text-emerald-500"/> Format Conversion
                                </h3>
                                <p className="text-sm text-slate-400">
                                    If your data is in PLINK binary format (<code
                                    className="bg-slate-800 px-1 rounded text-xs text-slate-300">.bed/.bim/.fam</code>),
                                    convert it using the command below:
                                </p>
                                <div
                                    className="bg-black/40 rounded-lg border border-white/5 p-4 font-mono text-sm text-emerald-100/90 overflow-x-auto">
                                    <span
                                        className="select-all">plink --bfile filename --recodeA --out recodefile</span>
                                </div>
                            </div>

                            {/* Mobile only download button */}
                            <button
                                className="w-full md:hidden flex items-center justify-center gap-2 px-5 py-3 bg-emerald-600 text-white rounded-lg font-medium text-sm">
                                <Download size={18}/> Download Sample Data
                            </button>
                        </div>
                    </div>

                    {/* Card 2: Environmental Data */}
                    <div
                        className="group bg-slate-900/50 backdrop-blur-sm border border-white/5 rounded-2xl overflow-hidden hover:border-blue-500/30 transition-all duration-300">
                        <div className="p-6 md:p-8 space-y-6">

                            {/* Card Header */}
                            <div className="flex items-center gap-4">
                                <div
                                    className="p-3 bg-blue-500/10 rounded-xl text-blue-400 group-hover:bg-blue-500/20 transition-colors">
                                    <Globe size={28}/>
                                </div>
                                <div>
                                    <h2 className="text-xl font-bold text-white">Environmental Data</h2>
                                    <p className="text-sm text-slate-500">Automated Integration Service</p>
                                </div>
                            </div>

                            <hr className="border-white/5"/>

                            <div className="flex flex-col md:flex-row gap-6">
                                <div className="flex-1 space-y-4">
                                    <p className="text-slate-400 leading-relaxed text-sm">
                                        Manual upload is <span
                                        className="text-slate-200 font-semibold">not required</span> for environmental
                                        data.
                                        Our system supports automatic acquisition and integration based on geospatial
                                        selection.
                                    </p>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                                        <div
                                            className="bg-slate-950/30 border border-white/5 p-4 rounded-lg flex items-start gap-3">
                                            <Map className="w-5 h-5 text-blue-400 mt-0.5"/>
                                            <div>
                                                <h4 className="text-slate-200 font-medium text-sm">Region Selection</h4>
                                                <p className="text-xs text-slate-500 mt-1">Select your area of interest
                                                    on the main map interface.</p>
                                            </div>
                                        </div>
                                        <div
                                            className="bg-slate-950/30 border border-white/5 p-4 rounded-lg flex items-start gap-3">
                                            <FileCode className="w-5 h-5 text-blue-400 mt-0.5"/>
                                            <div>
                                                <h4 className="text-slate-200 font-medium text-sm">Auto Retrieval</h4>
                                                <p className="text-xs text-slate-500 mt-1">System automatically fetches
                                                    indicators after confirmation.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}
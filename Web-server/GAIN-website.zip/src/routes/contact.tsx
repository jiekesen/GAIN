import {createFileRoute} from '@tanstack/react-router';
import {ArrowUpRight, BookOpen, FileText, Mail, MapPin} from 'lucide-react';

export const Route = createFileRoute('/contact')({
    component: RouteComponent,
})

// --- Mock Data ---
const TEAM_MEMBERS = [
    {
        name: "Dr. Hao Wang",
        email: "wanghao05@caas.cn",
        address: "Tobacco Research Institute, Chinese Academy of Agricultural Sciences, Qingdao, 266101, China",
        color: "from-blue-500 to-cyan-400"
    },
    {
        name: "Dr. Shen Yan",
        email: "yanshen@caas.cn",
        address: "Institute of Crop Sciences, Chinese Academy of Agricultural Sciences, Beijing 100081, China",
        color: "from-emerald-500 to-teal-400"
    },
    {
        name: "Dr. Wei Fang",
        email: "fangwei@caas.cn",
        address: "Institute of Crop Sciences, Chinese Academy of Agricultural Sciences, Beijing 100081, China",
        color: "from-purple-500 to-indigo-400"
    },

];

const PUBLICATIONS = [
    {
        year: "2025",
        title: "Large-scale genomic and phenomic analyses of modern cultivars empower future rice breeding design",
        journal: "Molecular Plant",
        authors: "Xiaoding Ma, Hao Wang, Shen Yan, Chuanqing Zhou, Kunneng Zhou, Qiang Zhang, Maomao Li, Yaolong Yang, Danting Li, Peng Song, Cuifeng Tang, Leiyue Geng, Jianchang Sun, Zhiyuan Ji, Xianjun Sun, Yongli Zhou, Peng Zhou, Di Cui,Bing Han, Xin Jing, Qiang He, Wei Fang , Longzhi Han.",
        link: "https://doi.org/10.1016/j.molp.2025.03.007"
    },
    {
        year: "2025",
        title: "Cropformer: An interpretable deep learning framework for crop genomic prediction",
        journal: "Plant Communications",
        authors: "Hao Wang, Shen Yan, Wenxi Wang, Yongming Chen, Jingpeng Hong , Qiang He, Xianmin Diao, Yunan Lin , Yanqing Chen, Yongsheng Cao, Weilong Guo, Wei Fang.",
        link: "https://doi.org/10.1016/j.xplc.2024.101223"
    },
    {
        year: "2024",
        title: "DeepCCR: large-scale genomics-based deep learning method for improving rice breeding",
        journal: "Plant Biotechnology Journal",
        authors: "Xiaoding Ma, Hao Wang, Shengyang Wu, Bing Han, Di Cui, Jin Liu, Qiang Zhang, Xiuzhong Xia, Peng Song, Cuifeng Tang, Leiyue Geng, Yaolong Yang, Shen Yan, Kunneng Zhou, Longzhi Han.",
        link: " https://doi.org/10.1111/pbi.14384"
    },
];

function RouteComponent() {

    // 1. 在组件内部计算布局样式 (放在 return 之前)
    const count = TEAM_MEMBERS.length;
    let gridConfig = "";

// 根据数量应用不同的 Grid 策略
    switch (count) {
        case 1:
            // 1个人：居中，限制最大宽度
            gridConfig = "grid-cols-1 max-w-md mx-auto";
            break;
        case 2:
            // 2个人：中屏变2列，限制整体宽度以免太散
            gridConfig = "grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto";
            break;
        case 3:
            // 3个人：标准的3列
            gridConfig = "grid-cols-1 md:grid-cols-3";
            break;
        default:
            // 4个及以上：中屏2列(2x2)，超大屏4列
            gridConfig = "grid-cols-1 md:grid-cols-2 xl:grid-cols-4";
            break;
    }

    return (
        <div
            className="min-h-full bg-slate-950 text-slate-200 font-sans selection:bg-emerald-500/30 p-6 md:p-12 overflow-y-auto custom-scrollbar relative isolate">

            {/* Ambient Background Effects */}
            <div
                className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-96 bg-emerald-500/10 rounded-full blur-[100px] -z-10 pointer-events-none"/>
            <div
                className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[80px] -z-10 pointer-events-none"/>

            <div className="max-w-6xl mx-auto space-y-16 pb-20">

                {/* 1. Header Section */}
                <div className="text-center space-y-6 animate-in slide-in-from-top-4 fade-in duration-700">
                    <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
                        Connect with our Lab
                    </h1>
                </div>

                {/* 2. Team Cards (Contact Persons) */}
                {/* 将计算好的 gridConfig 放入 className */}
                <div
                    className={`grid gap-6 animate-in slide-in-from-bottom-8 fade-in duration-700 delay-150 ${gridConfig}`}>
                    {TEAM_MEMBERS.map((member, idx) => (
                        <div key={idx}
                             className="group relative bg-slate-900/40 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:border-emerald-500/30 transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">

                            {/* Top Gradient Line */}
                            <div
                                className={`absolute top-0 left-0 right-0 h-1 rounded-t-2xl bg-linear-to-r ${member.color} opacity-0 group-hover:opacity-100 transition-opacity`}/>

                            {/* Header: Avatar & Name */}
                            <div className="flex items-center gap-4 mb-6">
                                <div
                                    className={`w-14 h-14 shrink-0 rounded-full bg-linear-to-br ${member.color} flex items-center justify-center text-white font-bold text-xl shadow-lg`}>
                                    {member.name.split(' ').map(n => n[0]).join('').slice(-2)}
                                </div>
                                <h3 className="text-xl font-bold text-white leading-tight">
                                    {member.name}
                                </h3>
                            </div>

                            {/* Contact Details List */}
                            <div className="space-y-4 pt-4 border-t border-white/5">
                                {/* Email Row */}
                                <div className="flex items-start gap-3 group/item">
                                    <div
                                        className="p-2 rounded bg-slate-800/50 text-slate-400 group-hover/item:text-emerald-400 group-hover/item:bg-emerald-500/10 transition-colors">
                                        <Mail size={16}/>
                                    </div>
                                    <div>
                                        <p className="text-xs text-slate-500 uppercase font-semibold mb-0.5">Email</p>
                                        <a href={`mailto:${member.email}`}
                                           className="text-sm text-slate-300 hover:text-white transition-colors break-all">
                                            {member.email}
                                        </a>
                                    </div>
                                </div>

                                {/* Address Row */}
                                <div className="flex items-start gap-3 group/item">
                                    <div
                                        className="p-2 rounded bg-slate-800/50 text-slate-400 group-hover/item:text-blue-400 group-hover/item:bg-blue-500/10 transition-colors">
                                        <MapPin size={16}/>
                                    </div>
                                    <div>
                                        <p className="text-xs text-slate-500 uppercase font-semibold mb-0.5">Address</p>
                                        <p className="text-sm text-slate-300 leading-snug">
                                            {member.address}
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    ))}
                </div>


                {/* 4. Publications Section */}
                {PUBLICATIONS &&
                <div className="animate-in slide-in-from-bottom-8 fade-in duration-700 delay-300">
                    <div className="flex items-center gap-3 mb-6">
                        <BookOpen className="text-emerald-400" size={24}/>
                        <h2 className="text-2xl font-bold text-white">Publications</h2>
                    </div>

                    <div className="grid gap-4">
                        {PUBLICATIONS.map((pub, idx) => (
                            <div key={idx}
                                 className="group flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-slate-900/30 border border-white/5 rounded-xl hover:bg-slate-900/60 hover:border-emerald-500/20 transition-all duration-300">
                                <div className="space-y-1">
                                    <div className="flex items-center gap-3">
                                        <span
                                            className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-slate-800 text-slate-400 group-hover:bg-emerald-500/10 group-hover:text-emerald-400 transition-colors">
                                            {pub.year}
                                        </span>
                                        <span className="text-xs text-emerald-500 font-medium tracking-wide uppercase">
                                            {pub.journal}
                                        </span>
                                    </div>
                                    <h4 className="text-lg font-semibold text-slate-200 group-hover:text-white transition-colors">
                                        {pub.title}
                                    </h4>
                                    <p className="text-sm text-slate-500">
                                        {pub.authors}
                                    </p>
                                </div>
                                <a
                                    href={pub.link}
                                    className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-sm font-medium hover:bg-white hover:text-slate-950 transition-all"
                                >
                                    <FileText size={16}/> Read Paper <ArrowUpRight size={16}/>
                                </a>
                            </div>
                        ))}
                    </div>
                </div>
                }

            </div>
        </div>
    )
}
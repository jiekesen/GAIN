import {Leaf} from "lucide-react";
import {Link} from "@tanstack/react-router";

// 配置化菜单项
const NAV_ITEMS = [
    {label: "Home", path: "/"},
    {label: "Workflow", path: "/workflow"},
    {label: "Data Examples", path: "/example"},
    {label: "Contact", path: "/contact"},
];

export const Navbar = () => {
    return (
        // 1. 容器：
        // - border-border: 使用全局定义的玻璃边框
        // - bg-background/60: 继承深海背景并半透明
        // - backdrop-blur-md: 毛玻璃效果
        <header className="sticky top-0 z-50 w-full border-b border-border bg-navy-900/80 backdrop-blur-md">
            <div className="container mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
                <nav
                    className="h-16 w-full border-b border-border bg-background/60 backdrop-blur-md sticky top-0 z-50 flex-none">
                    <div className="h-full w-full px-6 flex items-center justify-between">

                        {/* 2. Logo 区域 */}
                        <Link to="/" className="flex items-center gap-3 group">
                            <div
                                className="w-8 h-8 rounded-lg bg-linear-to-tr from-emerald-600 to-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                                <Leaf size={18} className="text-white"/>
                            </div>
                            <span
                                className="text-lg font-bold bg-clip-text text-transparent bg-linear-to-r from-emerald-400 to-blue-400">
                        {/*RiceG×E Predictor*/}
                                GAIN predicts rice development potential.
                    </span>
                        </Link>

                        {/* 3. 桌面端菜单 */}
                        <div className="hidden md:flex items-center gap-1">
                            {NAV_ITEMS.map((item) => (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    // 默认样式：文字静音色(muted)，悬停微亮
                                    className="px-4 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-brand hover:bg-brand/5 transition-all"
                                    // 激活样式：品牌色文字 + 极淡的品牌色背景 + 边框
                                    activeProps={{
                                        className: "!text-brand bg-brand/10 font-semibold shadow-[0_0_10px_rgba(0,229,255,0.1)]"
                                    }}
                                    activeOptions={{exact: item.path === "/"}}
                                >
                                    {item.label}
                                </Link>
                            ))}
                        </div>

                    </div>
                </nav>
            </div>
        </header>
    );
};
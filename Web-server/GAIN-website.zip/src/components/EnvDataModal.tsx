import {useMemo, useState} from 'react';
import {ENV_FACTORS, type EnvFactor, type Modification, usePredictionStore} from '../store/usePredictionStore';
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog";
import {Button} from "@/components/ui/button";
import {Slider} from "@/components/ui/slider";
import {
    CartesianGrid,
    Legend,
    Line,
    LineChart,
    ReferenceArea,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis
} from 'recharts';
import {Check, Eraser, MousePointerClick, Settings2, X} from 'lucide-react';

const UNIT_MAP: Record<EnvFactor, string> = {
    "ALLSKY_SFC_PAR_TOT": "W/m²",
    "ALLSKY_SFC_UVA": "W/m²",
    "ALLSKY_SFC_UVB": "W/m²",
    "GWETPROF": "fraction",
    "GWETROOT": "fraction",
    "PRECTOTCORR": "mm/day",
    "PS": "kPa",
    "RH2M": "%",
    "T2M_MAX": "°C",
    "T2M_MIN": "°C",
    "WD2M": "Degrees",
    "WS2M": "m/s"
};

const UNIT_FULL_NAME_MAP: Record<EnvFactor, string> = {
    "ALLSKY_SFC_PAR_TOT": "All Sky Surface Photosynthetically Active Radiation",
    "ALLSKY_SFC_UVA": "All Sky Surface UVA Irradiance",
    "ALLSKY_SFC_UVB": "All Sky Surface UVB Irradiance",
    "GWETPROF": "Profile Soil Moisture", // 或者直接用 "Fraction"
    "GWETROOT": "Root Zone Soil Wetness",
    "PRECTOTCORR": "Precipitation Corrected",
    "PS": "Surface Pressure",
    "RH2M": "Humidity at 2 Meters",
    "T2M_MAX": "Maximum Temperature at 2 Meters",
    "T2M_MIN": "Minimum Temperature at 2 Meters",
    "WD2M": "Wind Direction at 2 Meters",
    "WS2M": "Wind Speed at 2 Meters"
};

// 1. 修复 ESLint Any: 定义 Recharts 事件类型接口
interface RechartsEvent {
    activeLabel?: string | number;
    activePayload?: unknown[];
    activeCoordinate?: { x: number; y: number };
}

export const EnvDataModal = () => {
    // === 1. 所有 Hooks 必须在最顶层调用 ===

    const {
        isEnvModalOpen, closeEnvModal,
        envData, modificationsMap, coordinates,
        addModification, removeModification, clearModifications
    } = usePredictionStore();

    const [activeFactor, setActiveFactor] = useState<EnvFactor>('ALLSKY_SFC_PAR_TOT');

    // 本地交互状态
    const [selection, setSelection] = useState<{ start: number | null, end: number | null }>({start: null, end: null});
    const [isDragging, setIsDragging] = useState(false);
    const [currentSliderVal, setCurrentSliderVal] = useState(0);

    // === 2. 安全的数据获取 (防止 envData 为 null 导致下方 Hook 报错) ===
    // 即使 envData 为空，也要给默认值，保证 Hook 继续执行
    const storedDataPoints = envData?.[activeFactor] ?? [];
    const savedModifications = modificationsMap?.[activeFactor] ?? [];

    const isFraction = activeFactor.includes("GWET");
    const step = isFraction ? 0.01 : 0.5;
    const maxRange = isFraction ? 0.5 : 20;

    // === 3. useMemo (修复：现在它不会因为提前 Return 而被跳过) ===
    const chartData = useMemo(() => {
        // 如果没有数据，返回空数组
        if (!storedDataPoints || storedDataPoints.length === 0) return [];

        // 如果没有正在操作选区，直接展示 Store 数据
        if (currentSliderVal === 0 || selection.start === null || selection.end === null) {
            return storedDataPoints;
        }

        const start = Math.min(selection.start, selection.end);
        const end = Math.max(selection.start, selection.end);

        return storedDataPoints.map((point) => {
            let previewValue = point.value;
            if (point.day >= start && point.day <= end) {
                previewValue += currentSliderVal;
            }
            return {
                ...point,
                value: previewValue
            };
        });
    }, [storedDataPoints, selection, currentSliderVal]);

    // === 4. 事件处理函数 (修复 ESLint Any) ===

    const handleMouseDown = (e: RechartsEvent) => { // 使用定义的接口
        if (e && e.activeLabel !== undefined) {
            setSelection({start: Number(e.activeLabel), end: Number(e.activeLabel)});
            setIsDragging(true);
            setCurrentSliderVal(0);
        }
    };

    const handleMouseMove = (e: RechartsEvent) => {
        if (isDragging && e && e.activeLabel !== undefined) {
            setSelection(prev => ({...prev, end: Number(e.activeLabel)}));
        }
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const commitModification = () => {
        if (currentSliderVal === 0 || selection.start === null || selection.end === null) return;

        const newMod: Modification = {
            id: Date.now().toString(),
            start: Math.min(selection.start, selection.end),
            end: Math.max(selection.start, selection.end),
            value: currentSliderVal,
        };

        addModification(activeFactor, newMod);
        setCurrentSliderVal(0);
    };

    const handleFactorChange = (factor: EnvFactor) => {
        setActiveFactor(factor);
        setSelection({start: null, end: null});
        setCurrentSliderVal(0);
    };

    // === 5. 所有的 Hooks 执行完后，才可以进行条件渲染 (Early Return) ===
    if (!isEnvModalOpen || !envData || Object.keys(envData).length === 0) return null;

    const formatXAxisDate = (tickValue: string | number) => {
        // 1. 设定起始日期：2024年4月1日 (年份可根据需要修改)
        // 注意：JavaScript 中月份是从 0 开始的，所以 3 代表 4月
        const date = new Date(2024, 3, 1);

        // 2. 根据当前的 tickValue (假设是天数索引) 增加天数
        // 如果你的 day 数据是从 1 开始的，需要减 1；如果是从 0 开始则不用减
        date.setDate(date.getDate() + (parseInt(String(tickValue)) - 1));

        // 3. 格式化为英文 (例如: "Apr 01")
        return date.toLocaleDateString('en-US', {
            month: 'short', // 'short' = Apr, 'long' = April
            day: '2-digit'  // '2-digit' = 01, 'numeric' = 1
        });
    };

    return (
        <Dialog open={isEnvModalOpen} onOpenChange={closeEnvModal}>
            <DialogContent
                className="max-w-[90vw]! w-full! h-[90vh]! bg-navy-950 border border-border-glass flex flex-col p-0 overflow-hidden text-slate-200 shadow-2xl select-none">

                {/* Header */}
                <DialogHeader
                    className="p-5 border-b border-white/5 bg-navy-900 shrink-0 flex flex-row items-center justify-between space-y-0">
                    <DialogTitle className="flex items-center gap-2 text-slate-100">
                        <div className="p-1.5 rounded bg-white/5 border border-white/10">
                            <Settings2 className="w-4 h-4 text-brand"/>
                        </div>
                        <span>Segmented Adjustment</span>

                        <div className="w-px h-8 bg-white/10 mx-1"/>
                        {coordinates && (
                            <div className="flex flex-col">
                                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Location Locked</span>
                                <span className="text-xs font-mono text-white group-hover:text-brand transition-colors">
                                                    {coordinates.lat.toFixed(3)}, {coordinates.lng.toFixed(3)} ({coordinates.country_name})
                                                </span>
                            </div>
                        )}
                    </DialogTitle>
                </DialogHeader>

                <div className="flex flex-1 overflow-hidden">
                    {/* Left Sidebar */}
                    <div className="w-100 bg-navy-900 border-r border-white/5 overflow-y-auto p-2 space-y-1">
                        {ENV_FACTORS.map((factor) => {
                            // 安全访问 modificationsMap
                            const hasMods = (modificationsMap?.[factor]?.length || 0) > 0;
                            return (
                                <button
                                    key={factor}
                                    onClick={() => handleFactorChange(factor)}
                                    className={`w-full text-left px-4 py-3 rounded-lg transition-all flex justify-between items-center group border border-transparent ${
                                        activeFactor === factor
                                            ? 'bg-navy-800 text-slate-100 border-l-brand border-l-2 border-y-white/5 border-r-white/5'
                                            : 'text-slate-500 hover:bg-white/5 hover:text-slate-300'
                                    }`}
                                >
                                    <div className="flex flex-col truncate">
                                        <span
                                            className="font-mono text-xs font-bold truncate tracking-tight">{UNIT_FULL_NAME_MAP[factor]}</span>
                                        <span className="text-[10px] opacity-50 font-sans">{UNIT_MAP[factor]}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        {hasMods && activeFactor !== factor &&
                                            <div className="w-1.5 h-1.5 rounded-full bg-slate-600"/>}
                                        {activeFactor === factor &&
                                            <div className="w-1.5 h-1.5 rounded-full bg-brand opacity-80"/>}
                                    </div>
                                </button>
                            );
                        })}
                    </div>

                    {/* Right Content */}
                    <div className="flex-1 p-6 flex flex-col bg-navy-950 relative overflow-hidden">

                        {/* 顶部工具栏 */}
                        <div className="flex justify-between items-end mb-4 shrink-0">
                            <div>
                                <h2 className="text-2xl font-bold text-white tracking-tight font-mono">{UNIT_FULL_NAME_MAP[activeFactor]}</h2>
                                <div className="flex items-center gap-4 mt-1">
                                    <p className="text-slate-500 text-xs">Unit: <span
                                        className="text-slate-300 font-mono bg-white/5 px-1.5 rounded">{UNIT_MAP[activeFactor]}</span>
                                    </p>
                                    <div
                                        className="flex items-center gap-1.5 text-xs text-brand/80 bg-brand/5 px-2 py-0.5 rounded border border-brand/20">
                                        <MousePointerClick className="w-3 h-3"/>
                                        <span>Drag to select range</span>
                                    </div>
                                </div>
                            </div>
                            <Button
                                variant="outline" size="sm"
                                onClick={() => {
                                    clearModifications(activeFactor);
                                    setSelection({start: null, end: null});
                                    setCurrentSliderVal(0);
                                }}
                                className="border-white/10 bg-transparent hover:bg-white/5 text-slate-400 hover:text-red-400 h-8 text-xs"
                            >
                                <Eraser className="w-3.5 h-3.5 mr-2"/> Clear All
                            </Button>
                        </div>

                        {/* 图表区域 */}
                        <div
                            className="flex-1 min-h-0 bg-navy-900/50 rounded-xl border border-white/5 p-4 mb-4 relative select-none">
                            <div
                                className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-size-[40px_40px] pointer-events-none rounded-xl"/>

                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart
                                    data={chartData}
                                    onMouseDown={handleMouseDown}
                                    onMouseMove={handleMouseMove}
                                    onMouseUp={handleMouseUp}
                                >
                                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)"
                                                   vertical={false}/>
                                    <XAxis dataKey="day" stroke="#475569" tick={{fill: '#64748B', fontSize: 10}}
                                           tickLine={false} axisLine={false} minTickGap={30}
                                           tickFormatter={formatXAxisDate}/>
                                    <YAxis stroke="#475569" tick={{fill: '#64748B', fontSize: 10}} tickLine={false}
                                           axisLine={false} domain={['auto', 'auto']} width={40}/>
                                    <Tooltip contentStyle={{
                                        backgroundColor: '#0B1221',
                                        borderColor: 'rgba(255,255,255,0.1)'
                                    }} itemStyle={{fontSize: '12px'}}
                                             labelFormatter={(label) => formatXAxisDate(label)}
                                    />
                                    <Legend verticalAlign="top" height={36} iconType="circle" iconSize={8}
                                            wrapperStyle={{fontSize: '12px', opacity: 0.8}}/>

                                    <Line type="monotone" dataKey="originalValue" name="Original" stroke="#475569"
                                          strokeDasharray="3 3" dot={false} strokeWidth={1.5}/>
                                    <Line type="monotone" dataKey="value" name="Modified" stroke="#0891b2" dot={false}
                                          strokeWidth={2}
                                          activeDot={{r: 5, fill: "#0891b2", stroke: "#020408", strokeWidth: 2}}/>

                                    {/* 选区高亮 */}
                                    {selection.start !== null && selection.end !== null && (
                                        <ReferenceArea
                                            x1={selection.start}
                                            x2={selection.end}
                                            strokeOpacity={0}
                                            fill="#00E5FF"
                                            fillOpacity={0.1}
                                        />
                                    )}
                                </LineChart>
                            </ResponsiveContainer>
                        </div>

                        {/* 底部面板：滑块 + Tags */}
                        <div className="h-48 shrink-0 flex flex-col gap-4">

                            {/* Slider */}
                            <div
                                className={`bg-navy-900 border border-white/5 rounded-xl p-4 transition-all ${selection.start !== null ? 'opacity-100' : 'opacity-50 grayscale pointer-events-none'}`}>
                                <div className="flex justify-between mb-2 items-center">
                                    <span className="text-sm font-bold text-slate-200">
                                        {selection.start !== null
                                            ? `Adjust Range: ${formatXAxisDate(Math.min(selection.start, selection.end!))} - ${formatXAxisDate(Math.max(selection.start, selection.end!))}`
                                            : "Select range on chart to enable adjustment"}
                                    </span>
                                    <div className="flex items-center gap-2">
                                        <div
                                            className="text-lg font-mono text-cyan-500 font-bold bg-navy-950 px-3 py-0.5 rounded border border-white/10 min-w-[60px] text-center">
                                            {currentSliderVal > 0 ? '+' : ''}{currentSliderVal.toFixed(2)}
                                        </div>
                                        <Button
                                            size="sm" onClick={commitModification} disabled={currentSliderVal === 0}
                                            className="h-8 bg-cyan-600 hover:bg-cyan-500 text-white border border-cyan-500/20"
                                        >
                                            Apply
                                        </Button>
                                    </div>
                                </div>
                                <Slider
                                    value={[currentSliderVal]}
                                    min={-maxRange} max={maxRange} step={step}
                                    onValueChange={(val) => setCurrentSliderVal(val[0])}
                                    className="py-2 cursor-pointer"
                                />
                            </div>

                            {/* Tags 列表 */}
                            <div className="flex-1 overflow-y-auto pr-1">
                                <div className="flex flex-wrap gap-2 content-start">
                                    {savedModifications.length === 0 && (
                                        <div
                                            className="w-full text-center text-xs text-slate-600 py-2 border border-dashed border-white/5 rounded-lg">
                                            No modifications applied yet.
                                        </div>
                                    )}
                                    {savedModifications.map((mod) => (
                                        <div
                                            key={mod.id}
                                            className="group flex items-center gap-2 pl-3 pr-1 py-1 bg-navy-800 border border-white/10 rounded-full text-xs text-slate-300 animate-in zoom-in-95"
                                        >
                                            <span
                                                className="font-mono text-slate-500">{formatXAxisDate(mod.start)} - {formatXAxisDate(mod.end)}</span>
                                            <span
                                                className={`font-bold ${mod.value > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                                {mod.value > 0 ? '+' : ''}{mod.value}
                                            </span>
                                            <button
                                                onClick={() => removeModification(activeFactor, mod.id)}
                                                className="p-1 rounded-full hover:bg-white/10 text-slate-500 hover:text-white transition-colors"
                                            >
                                                <X className="w-3 h-3"/>
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* 底部完成按钮 */}
                        <div className="absolute bottom-6 right-6">
                            <Button
                                onClick={closeEnvModal}
                                size="lg"
                                className="bg-cyan-600 hover:bg-cyan-500 text-white shadow-md border border-cyan-500/20 font-semibold"
                            >
                                <Check className="w-5 h-5 mr-2"/> Done
                            </Button>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};
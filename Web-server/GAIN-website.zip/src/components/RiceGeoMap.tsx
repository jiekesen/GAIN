import * as React from "react";
import Map, {Layer, type MapLayerMouseEvent, type MapRef, Marker, Source} from "react-map-gl/maplibre";
import "maplibre-gl/dist/maplibre-gl.css";
import {usePredictionStore} from "../store/usePredictionStore";
import {MapPin} from "lucide-react";
import type {StyleSpecification} from "maplibre-gl";

// --- 1. 配色升级：适配 "深海·极光" 主题 ---
// 背景使用 Navy-950 (#020408)，陆地使用 Navy-900 (#050A14)
const MAP_STYLE: StyleSpecification = {
    version: 8,
    sources: {},
    layers: [{
        id: 'background',
        type: 'background',
        paint: {'background-color': '#020408'} // Navy-950
    }]
};

const INITIAL_VIEW_STATE = {longitude: 105, latitude: 25, zoom: 1.8};


export function RiceGeoMap() {
    const mapRef = React.useRef<MapRef>(null);

    const {
        coordinates,
        useEnvironment,
        isMapPicking,
        startMapPicking,
        confirmLocation
    } = usePredictionStore();

    // 自动进入选点模式逻辑
    React.useEffect(() => {
        if (useEnvironment && !coordinates && !isMapPicking) {
            startMapPicking();
        }
    }, [useEnvironment, coordinates, isMapPicking, startMapPicking]);

    // --- 新增：监听坐标清空，还原视图 ---
    React.useEffect(() => {
        // 如果 coordinates 变为 null (用户点击了清除)，且地图实例存在
        if (!coordinates && mapRef.current) {
            mapRef.current.flyTo({
                ...INITIAL_VIEW_STATE,
                duration: 2000, // 2秒平滑飞回
                essential: true // 确保动画不被用户交互打断
            });
        }
    }, [coordinates]);

    // --- 交互处理 ---

    const onMouseEnter = React.useCallback(() => {
        if (isMapPicking && mapRef.current) {
            mapRef.current.getCanvas().style.cursor = 'pointer';
        }
    }, [isMapPicking]);

    const onMouseLeave = React.useCallback(() => {
        if (mapRef.current) {
            mapRef.current.getCanvas().style.cursor = 'default';
        }
    }, []);

    const onClick = React.useCallback((e: MapLayerMouseEvent) => {
        if (!isMapPicking) return;

        if (e.features && e.features.length > 0) {

            // --- 新增逻辑开始 ---
            // 1. 在所有被点击的 feature 中，查找属于 'land-fill' 图层的 feature
            const landFeature = e.features.find(f => f.layer.id === 'land-fill');

            // 2. 获取国家名称 (注意：GeoJSON 的属性都在 properties 对象里)
            // 假设你的 geojson 字段名确实是 'name'，如果是 'NAME' 或 'admin' 请相应修改
            const countryName = landFeature?.properties?.name || "Unknown Region";


            const rawLng = e.lngLat.lng;
            const rawLat = e.lngLat.lat;

            // const snappedLng = snapCenter1Deg(rawLng);
            // const snappedLat = snapCenter1Deg(rawLat);

            const snappedLng = rawLng;
            const snappedLat = rawLat;

            confirmLocation(snappedLat, snappedLng, countryName);

            // 点击后放大视图 (Zoom In)
            mapRef.current?.flyTo({
                center: [snappedLng, snappedLat],
                zoom: 4.5, // 稍微再近一点，看得更清
                speed: 1.2,
                essential: true
            });

            if (mapRef.current) {
                mapRef.current.getCanvas().style.cursor = 'default';
            }
        }
    }, [isMapPicking, confirmLocation]);

    return (
        <div style={{height: "100%", width: "100%", position: "relative", backgroundColor: "#020408"}}>
            <Map
                ref={mapRef}
                initialViewState={INITIAL_VIEW_STATE}
                mapStyle={MAP_STYLE}
                attributionControl={false}
                doubleClickZoom={false}
                interactiveLayerIds={["zones-hit", "land-fill"]}
                onClick={onClick}
                onMouseEnter={onMouseEnter}
                onMouseLeave={onMouseLeave}
            >
                {/* 1. 基础陆地层 (Navy-900) */}
                <Source id="land" type="geojson" data="/geo/countries.geojson">
                    <Layer
                        id="land-fill"
                        type="fill"
                        paint={{
                            "fill-color":"#27272A",
                            "fill-opacity": 1
                        }}
                    />
                    <Layer
                        id="coastline"
                        type="line"
                        paint={{
                            "line-color": "#27272A", // Navy-700: 极低调的边界
                            "line-width": 1,
                            "line-opacity": 0.5
                        }}
                    />
                </Source>

                {/* 2. 水稻分布 (Bio-Lum 配色: 深蓝 -> 品牌青 -> 亮白) */}
                <Source id="rice-dist" type="geojson" data="/geo/rice_distribution.geojson">
                    <Layer
                        id="rice-dist-fill"
                        type="fill"
                        paint={{
                            "fill-color": [
                                "interpolate",
                                ["linear"],
                                ["to-number", ["get", "DN"], 0],
                                0, "#27272A",
                                500, "#00D493",
                            ],
                            "fill-opacity": 0.7,
                            "fill-antialias": false
                        }}
                    />
                </Source>

                {/* 3. 交互网格层 */}
                <Source id="rice-zones" type="geojson" data="/geo/rice_suitable_zones.geojson">
                    {/* 视觉层: 品牌色线条，极低透明度 */}
                    <Layer
                        id="zones-outline"
                        type="line"
                        paint={{
                            "line-color": "#00E5FF",
                            "line-width": 0.5,
                            "line-opacity": 0.1,
                        }}
                    />

                    {/* 逻辑点击层 */}
                    <Layer
                        id="zones-hit"
                        type="fill"
                        paint={{"fill-color": "#ffffff", "fill-opacity": 0}}
                    />
                </Source>

                {/* 4. Marker */}
                {coordinates && (
                    <Marker
                        longitude={coordinates.lng}
                        latitude={coordinates.lat}
                        anchor="bottom"
                    >
                        <div className="relative flex flex-col items-center group pointer-events-none">
                            <div
                                className="absolute -top-8 bg-navy-900 border border-brand/30 px-2 py-1 rounded text-[10px] text-brand whitespace-nowrap shadow-[0_0_10px_rgba(0,229,255,0.2)]">
                                Lat: {coordinates.lat.toFixed(3)}, Lng: {coordinates.lng.toFixed(3)} ({coordinates.country_name})
                            </div>
                            <MapPin
                                className="w-8 h-8 text-brand fill-navy-950 drop-shadow-[0_0_8px_rgba(0,229,255,0.8)]"/>
                            <div
                                className="absolute bottom-0 w-3 h-3 bg-brand rounded-full animate-ping opacity-75"></div>
                        </div>
                    </Marker>
                )}

                {/* 5. 提示文案 */}
                {isMapPicking && !coordinates && (
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
                        <div
                            className="bg-brand/10 border border-brand text-brand px-6 py-2 rounded-full backdrop-blur-md text-sm font-bold animate-pulse shadow-[0_0_15px_rgba(0,229,255,0.3)] flex items-center gap-2">
                            <MapPin className="w-4 h-4"/>
                            Click highlighted zones to select location
                        </div>
                    </div>
                )}
            </Map>
        </div>
    );
}
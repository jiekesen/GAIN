import React, { useRef } from 'react';
import { usePredictionStore } from '../store/usePredictionStore';
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { FileDown, FileText, Loader2, MapPin, Play, Settings2, Upload, Zap, BarChart3, RotateCcw } from 'lucide-react';

export const ModelConsole = () => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const {
        file, setFile,
        useEnvironment, setUseEnvironment,coordinates, openEnvModal, isMapPicking,
        status, runPrediction,openResultModal
    } = usePredictionStore();

    const handleShowResult = () => {
        openResultModal();
    };

    const handleReset = () => {
        // 重置为闲置状态
        usePredictionStore.setState({ status: 'idle' });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    return (
        // 1. 容器：使用 Navy-900 作为基底
        <div className="w-full bg-navy-900 flex flex-col h-full relative font-sans text-slate-200">

            {/* === Header === */}
            <div className="p-6 pb-6 border-b border-border-glass bg-navy-900 z-20">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        {/* 图标：品牌色微光背景 */}
                        <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center border border-brand/20 shadow-[0_0_15px_rgba(0,229,255,0.1)]">
                            <Zap className="w-5 h-5 text-brand fill-brand/20"/>
                        </div>
                        <div>
                            {/* 纯白高亮标题 */}
                            <h2 className="text-base font-bold text-white tracking-wide">Model Console</h2>
                            <div className="flex items-center gap-2 mt-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"/>
                                <span className="text-[11px] text-slate-400 font-medium font-mono">SYSTEM ONLINE</span>
                            </div>
                        </div>
                    </div>
                    {/* 版本号 */}
                    <div className="px-2 py-1 rounded-md bg-white/5 border border-border-glass text-[10px] font-mono text-slate-500">
                        v2.1
                    </div>
                </div>
            </div>

            {/* === Content: 滚动区域 === */}
            <div className="flex-1 overflow-y-auto p-6 space-y-8 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">

                {/* 1. 文件上传 */}
                <div className="space-y-3">
                    <div className="flex justify-between items-center">
                        <label className="text-sm font-medium text-slate-200 pl-1 border-l-2 border-brand leading-none">
                            Genotype Input
                        </label>
                        <a
                            href="/assets/gene_example.csv"
                            download="gene_example.csv"
                            className="text-[10px] flex items-center gap-1 text-slate-400 hover:text-brand transition-colors"
                        >
                            <FileDown className="w-3 h-3"/> Template
                        </a>
                    </div>

                    <div
                        onClick={() => fileInputRef.current?.click()}
                        className={`
                            group relative h-32 rounded-xl border-2 border-dashed transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center
                            ${file
                            ? 'bg-brand/5 border-brand/50'
                            : 'bg-navy-950/50 border-border-glass hover:border-brand/30 hover:bg-navy-950'
                        }
                        `}
                    >
                        <input ref={fileInputRef} type="file" className="hidden" accept=".csv" onChange={handleFileChange}/>

                        {file ? (
                            <div className="flex flex-col items-center animate-in zoom-in-95 duration-300">
                                <FileText className="w-8 h-8 text-brand mb-3 drop-shadow-[0_0_8px_rgba(0,229,255,0.3)]"/>
                                <span className="text-sm font-medium text-white max-w-[200px] truncate">{file.name}</span>
                                <span className="text-[10px] text-brand/80 mt-1 font-mono">{(file.size / 1024).toFixed(1)} KB Loaded</span>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center">
                                <div className="p-3 rounded-full bg-white/5 mb-3 group-hover:scale-110 group-hover:bg-brand/10 transition-all duration-300">
                                    <Upload className="w-5 h-5 text-slate-400 group-hover:text-brand transition-colors"/>
                                </div>
                                <span className="text-xs font-medium text-slate-400 group-hover:text-slate-200">Click or Drag CSV File</span>
                            </div>
                        )}
                    </div>
                </div>

                {/* 2. 环境模拟配置 */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-1">
                        <div className="flex flex-col">
                            <label className="text-sm font-medium text-slate-200 pl-1 border-l-2 border-brand leading-none">
                                Environment
                            </label>
                            <span className="text-[11px] text-slate-500 mt-1 ml-1.5">Include 12-factor weather data</span>
                        </div>

                        {/* --- 修复点 1：切换开关时清空状态 --- */}
                        <Switch
                            checked={useEnvironment}
                            onCheckedChange={(checked) => {
                                setUseEnvironment(checked);
                                if (!checked) {
                                    // 当关闭时，直接修改 Store 状态，清空坐标和选点模式
                                    usePredictionStore.setState({
                                        coordinates: null,
                                        isMapPicking: false
                                    });
                                }
                            }}
                            className="data-[state=checked]:bg-brand border-border-glass"
                        />
                    </div>

                    {useEnvironment && (
                        <div className="animate-in fade-in slide-in-from-top-2 duration-300 space-y-3">
                            {!coordinates ? (
                                // 状态指示框
                                <div className="w-full h-12 rounded-lg border border-dashed border-brand/30 bg-brand/5 flex items-center px-4 text-sm text-brand select-none animate-pulse cursor-default">
                                    <MapPin className="w-4 h-4 mr-3" />
                                    <span className="font-medium tracking-wide">
                                        {isMapPicking ? "Select location on map..." : "Waiting for selection..."}
                                    </span>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {/* 坐标卡片 */}
                                    <div className="bg-navy-950 rounded-lg p-3 flex justify-between items-center border border-border-glass group">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-md bg-white/5 flex items-center justify-center text-brand">
                                                <MapPin className="w-4 h-4"/>
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Location Locked</span>
                                                <span className="text-xs font-mono text-white group-hover:text-brand transition-colors">
                                                    {coordinates.lat.toFixed(3)}, {coordinates.lng.toFixed(3)} ({coordinates.country_name})
                                                </span>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => usePredictionStore.setState({coordinates: null})}
                                            className="w-6 h-6 flex items-center justify-center text-slate-600 hover:text-red-400 transition-colors"
                                        >
                                            ×
                                        </button>
                                    </div>

                                    {/* 配置按钮 */}
                                    <Button
                                        size="sm"
                                        onClick={openEnvModal}
                                        className="w-full h-9 bg-transparent border border-border-glass hover:border-brand/50 hover:bg-brand/5 text-slate-300 hover:text-brand transition-all font-medium"
                                    >
                                        <Settings2 className="w-3.5 h-3.5 mr-2"/>
                                        Configure Factors
                                    </Button>
                                </div>
                            )}
                            <p className="text-[10px] text-slate-500 ml-1">
                                * Simulates 200 days of weather data based on location.
                            </p>
                        </div>
                    )}
                </div>
            </div>

            {/* === Footer: 底部固定操作区 === */}
            <div className="p-6 border-t border-border-glass bg-navy-950/30 backdrop-blur-md z-20 mt-auto">

                {status !== 'success' && (
                    <Button
                        className={`
                            w-full h-12 text-sm font-bold tracking-widest uppercase rounded-lg transition-all
                            ${status === 'loading'
                            ? 'bg-navy-800 text-slate-500 cursor-not-allowed'
                            : 'bg-brand hover:bg-white text-navy-950 shadow-[0_0_20px_rgba(0,229,255,0.15)] hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]'
                        }
                        `}
                        disabled={!file || (useEnvironment && !coordinates) || status === 'loading'}
                        onClick={runPrediction}
                    >
                        {status === 'loading' ? (
                            <div className="flex items-center">
                                <Loader2 className="w-5 h-5 mr-2 animate-spin"/>
                                PROCESSING...
                            </div>
                        ) : (
                            <div className="flex items-center">
                                <Play className="w-5 h-5 mr-2 fill-current"/>
                                RUN PREDICTION
                            </div>
                        )}
                    </Button>
                )}

                {/* --- 修复点 2：适配结果按钮样式 --- */}
                {status === 'success' && (
                    <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2">
                        {/* 1. 结果按钮：使用 Emerald (祖母绿) 保持高对比度，代表成功 */}
                        <Button
                            onClick={handleShowResult}
                            className="w-full h-12 bg-emerald-500 hover:bg-emerald-400 text-navy-950 font-bold text-sm tracking-wide shadow-lg shadow-emerald-500/20 rounded-lg transition-all hover:scale-[1.02]"
                        >
                            <BarChart3 className="w-5 h-5 mr-2" />
                            VIEW ANALYSIS REPORT
                        </Button>

                        {/* 2. 重置按钮：使用 Ghost 风格，但增加微弱的背景悬停效果 */}
                        <Button
                            variant="ghost"
                            onClick={handleReset}
                            className="w-full h-9 text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-colors text-xs"
                        >
                            <RotateCcw className="w-3 h-3 mr-2" />
                            Reset Simulation
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
};
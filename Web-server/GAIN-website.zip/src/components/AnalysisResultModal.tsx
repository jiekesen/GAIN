import { useState, useEffect, useMemo } from 'react';
import { usePredictionStore } from '../store/usePredictionStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Download } from 'lucide-react';

export const AnalysisResultModal = () => {
    // 1. Hook: 获取全局状态
    const {
        isResultModalOpen,
        closeResultModal,
        predictionResult
    } = usePredictionStore();

    // 2. Hook: useMemo (必须在 if return 之前)
    // 即使 predictionResult 为空，这里也要执行，返回空数组即可
    const locationKeys = useMemo(() => {
        return predictionResult ? Object.keys(predictionResult) : [];
    }, [predictionResult]);

    // 3. Hook: useState (必须在 if return 之前)
    const [activeTab, setActiveTab] = useState<string>("");

    // 4. Hook: useEffect (必须在 if return 之前)
    useEffect(() => {
        if (locationKeys.length > 0) {
            // 如果当前没有选中 Tab，或者选中的 Tab 不在新的 Key 列表中
            if (!activeTab || !locationKeys.includes(activeTab)) {
                setActiveTab(locationKeys[0]);
            }
        }
    }, [locationKeys, activeTab]);

    // ============================================================
    // ⚠️ 分界线：所有的 Hooks 必须定义在这一行之前 ⚠️
    // ============================================================

    // 5. 条件判断 / 提前返回 (Early Return)
    // 只有当所有的 Hooks 都执行过后，才能决定是否不渲染组件
    if (!predictionResult || locationKeys.length === 0) return null;

    // 6. 渲染逻辑 (普通 JS 计算)
    // 确保渲染时使用的 Tab 是有效的
    const currentRenderTab = (activeTab && locationKeys.includes(activeTab)) ? activeTab : locationKeys[0];

    const handleExport = () => {
        const rows = predictionResult[currentRenderTab];
        if (!rows || rows.length === 0) return;

        const headers = Object.keys(rows[0]);
        const csvContent = [
            headers.join(','),
            ...rows.map(row => headers.map(fieldName => row[fieldName]).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `analysis_report_${currentRenderTab}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <Dialog open={isResultModalOpen} onOpenChange={closeResultModal}>
            <DialogContent className="max-w-[90vw]! w-full! h-[90vh]! bg-navy-950 border border-border-glass flex flex-col p-0 overflow-hidden text-slate-200 shadow-2xl select-none">

                <DialogHeader className="p-5 border-b border-white/5 bg-navy-900 shrink-0 flex flex-row items-center justify-between space-y-0">
                    <DialogTitle className="flex items-center gap-2 text-slate-100">
                        <div className="p-1.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                            <BarChart3 className="w-4 h-4 text-emerald-500" />
                        </div>
                        <span className="font-mono tracking-wide">Analysis Report</span>
                    </DialogTitle>
                </DialogHeader>

                <div className="flex-1 overflow-hidden bg-navy-950 p-6">
                    <Tabs value={currentRenderTab} onValueChange={setActiveTab} className="w-full h-full flex flex-col">

                        <div className="flex justify-between items-end mb-4 shrink-0 border-b border-white/5 pb-1">
                            <TabsList className="bg-transparent p-0 h-auto gap-4">
                                {locationKeys.map(loc => (
                                    <TabsTrigger
                                        key={loc}
                                        value={loc}
                                        className="
                                            rounded-none border-b-2 border-transparent px-4 py-2 font-mono text-sm uppercase text-slate-500
                                            data-[state=active]:border-brand data-[state=active]:bg-transparent data-[state=active]:text-brand
                                            hover:text-slate-300 transition-all
                                        "
                                    >
                                        {loc}
                                    </TabsTrigger>
                                ))}
                            </TabsList>

                            <div className="flex items-center gap-4 mb-1">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={handleExport}
                                    className="h-8 border-border-glass bg-transparent hover:bg-white/5 text-slate-400 hover:text-brand gap-2 text-xs"
                                >
                                    <Download className="w-3.5 h-3.5" />
                                    Export CSV
                                </Button>
                            </div>
                        </div>

                        {locationKeys.map(loc => {
                            const rows = predictionResult[loc];
                            if (!rows || rows.length === 0) return null;

                            const columns = Object.keys(rows[0]).filter(k => k !== 'sampleId');

                            return (
                                <TabsContent key={loc} value={loc} className="flex-1 overflow-hidden mt-0 data-[state=inactive]:hidden">
                                    <div className="h-full overflow-auto scrollbar-thin scrollbar-thumb-white/10 rounded-xl border border-white/5 bg-navy-900/30">
                                        <table className="w-full text-sm text-left border-collapse">
                                            <thead className="text-xs text-slate-400 uppercase bg-navy-900 sticky top-0 z-10 shadow-sm">
                                            <tr>
                                                <th className="px-6 py-4 font-bold text-brand bg-navy-900 border-b border-white/5 sticky left-0 z-20">
                                                    Sample ID
                                                </th>
                                                {columns.map(col => (
                                                    <th key={col} className="px-6 py-4 font-medium border-b border-white/5 whitespace-nowrap">
                                                        {col}
                                                    </th>
                                                ))}
                                            </tr>
                                            </thead>

                                            <tbody className="divide-y divide-white/5 font-mono text-slate-300">
                                            {rows.map((row, idx) => (
                                                <tr key={idx} className="hover:bg-white/5 transition-colors group">
                                                    <td className="px-6 py-3 font-bold text-slate-200 sticky left-0 bg-navy-950 group-hover:bg-navy-900 border-r border-white/5 transition-colors">
                                                        {row.sampleId}
                                                    </td>
                                                    {columns.map(col => (
                                                        <td key={col} className="px-6 py-3 text-slate-400 group-hover:text-slate-200">
                                                            {row[col]}
                                                        </td>
                                                    ))}
                                                </tr>
                                            ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </TabsContent>
                            );
                        })}
                    </Tabs>
                </div>

                <div className="p-5 border-t border-white/5 bg-navy-900 shrink-0 flex justify-end">
                    <Button
                        onClick={closeResultModal}
                        className="bg-brand hover:bg-brand-hover text-navy-950 font-bold px-8"
                    >
                        Close Report
                    </Button>
                </div>

            </DialogContent>
        </Dialog>
    );
};
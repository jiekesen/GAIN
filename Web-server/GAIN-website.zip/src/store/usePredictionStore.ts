import {create} from 'zustand';

// --- 1. 环境因子类型定义 (保持不变) ---
export type EnvFactor =
    | "ALLSKY_SFC_PAR_TOT"
    | "ALLSKY_SFC_UVA"
    | "ALLSKY_SFC_UVB"
    | "GWETPROF"
    | "GWETROOT"
    | "PRECTOTCORR"
    | "PS"
    | "RH2M"
    | "T2M_MAX"
    | "T2M_MIN"
    | "WD2M"
    | "WS2M";

export const ENV_FACTORS: EnvFactor[] = [
    "ALLSKY_SFC_PAR_TOT",
    "ALLSKY_SFC_UVA",
    "ALLSKY_SFC_UVB",
    "GWETPROF",
    "GWETROOT",
    "PRECTOTCORR",
    "PS",
    "RH2M",
    "T2M_MAX",
    "T2M_MIN",
    "WD2M",
    "WS2M"
];

// 修改记录结构 (保持不变)
export type Modification = {
    id: string;
    start: number;
    end: number;
    value: number;
};

// 单个数据点结构 (保持不变)
export interface DataPoint {
    day: number;
    value: number;
    originalValue: number;
}

// 结果数据的类型定义
export type AnalysisRow = {
    sampleId: string;
    [key: string]: string | number; // 动态键名 (如 HD, PH)
};

export type AnalysisResult = Record<string, AnalysisRow[]>;

interface PredictionState {
    file: File | null;
    setFile: (file: File | null) => void;
    useEnvironment: boolean;
    setUseEnvironment: (use: boolean) => void;
    coordinates: { lat: number; lng: number, country_name: string } | null;
    isMapPicking: boolean;
    startMapPicking: () => void;

    // 修改：改为异步方法，因为需要请求 API
    confirmLocation: (lat: number, lng: number, country_name: string) => Promise<void>;

    envData: Record<EnvFactor, DataPoint[]> | null; // 允许为 null
    isEnvModalOpen: boolean;
    openEnvModal: () => void;
    closeEnvModal: () => void;

    modificationsMap: Record<string, Modification[]>;

    addModification: (factor: EnvFactor, mod: Modification) => void;
    removeModification: (factor: EnvFactor, modId: string) => void;
    clearModifications: (factor: EnvFactor) => void;

    adjustEnvFactor: (factor: EnvFactor, offset: number) => void;
    resetEnvFactor: (factor: EnvFactor) => void;

    status: 'idle' | 'loading' | 'success' | 'error'; // 增加 error 状态
    error: string | null; // 保存错误信息
    runPrediction: () => Promise<void>;

    // 新增：结果模态框状态
    isResultModalOpen: boolean;
    openResultModal: () => void;
    closeResultModal: () => void;

    predictionResult: AnalysisResult | null;

}

// 辅助函数：根据修改记录重新计算数值 (保持不变)
const recalculateValues = (dataPoints: DataPoint[], mods: Modification[]) => {
    return dataPoints.map(point => {
        let totalOffset = 0;
        mods.forEach(mod => {
            if (point.day >= mod.start && point.day <= mod.end) {
                totalOffset += mod.value;
            }
        });
        return {
            ...point,
            value: point.originalValue + totalOffset
        };
    });
};

export const usePredictionStore = create<PredictionState>((set, get) => ({
    file: null,
    useEnvironment: false,
    isMapPicking: false,
    coordinates: null,
    envData: null,
    isEnvModalOpen: false,
    status: 'idle',
    error: null,
    modificationsMap: {},
    predictionResult: null,

    setFile: (file) => set({file}),
    setUseEnvironment: (use) => set({useEnvironment: use}),
    startMapPicking: () => set({isMapPicking: true}),


    // --- 核心修改：请求真实后端数据 ---
    confirmLocation: async (lat, lng, country_name) => {
        set({status: 'loading', error: null});

        try {
            // 1. 发起请求 (请替换为你的真实 API 地址)
            // 假设后端接口: GET /api/climate?lat=xx&lng=xx
            // 假设后端返回格式: { "T2M_MAX": [25.1, 25.3, ...], "PRECTOTCORR": [0, 0, ...] }
            const response = await fetch(`/api/climate?lat=${lat}&lng=${lng}`);

            if (!response.ok) {
                throw new Error(`API Error: ${response.statusText}`);
            }

            const apiResponse = await response.json();

            // 2. 数据转换: 将后端返回的纯数字数组，转换为前端需要的 DataPoint 对象数组
            const formattedData: Partial<Record<EnvFactor, DataPoint[]>> = {};

            ENV_FACTORS.forEach(factor => {
                // 如果后端返回的数据里缺少某个因子，给一个空数组防止报错
                const values = apiResponse[factor] || [];

                formattedData[factor] = values.map((val: number, index: number) => ({
                    day: index + 1,
                    value: val,          // 当前显示值
                    originalValue: val   // 原始值用于重置
                }));
            });

            // 3. 更新状态
            set({
                coordinates: {lat, lng, country_name},
                isMapPicking: false,
                envData: formattedData as Record<EnvFactor, DataPoint[]>,
                isEnvModalOpen: true, // 获取数据成功后自动打开弹窗
                status: 'idle',
                modificationsMap: {} // 切换地点后清空之前的修改记录
            });

        } catch (err: any) {
            console.error("Fetch environment data failed:", err);
            set({
                status: 'error',
                error: err.message || "Failed to fetch environment data"
            });
            // 可选：即使失败也关闭选点模式，或者保留以便重试
            set({isMapPicking: false});
        }
    },

    openEnvModal: () => set({isEnvModalOpen: true}),
    closeEnvModal: () => set({isEnvModalOpen: false}),

    // 简单调整偏移量 (兼容旧逻辑)
    adjustEnvFactor: (factor, offset) => set((state) => {
        if (!state.envData) return {};
        const currentList = state.envData[factor];
        const newList = currentList.map(item => ({
            ...item,
            value: parseFloat((item.originalValue + offset).toFixed(2))
        }));
        return {
            envData: {...state.envData, [factor]: newList}
        };
    }),

    // 重置单个因子
    resetEnvFactor: (factor) => set((state) => {
        if (!state.envData) return {};
        const currentList = state.envData[factor];
        const newList = currentList.map(item => ({
            ...item,
            value: item.originalValue
        }));
        // 同时清除该因子的修改记录
        const newModsMap = {...state.modificationsMap};
        delete newModsMap[factor];

        return {
            envData: {...state.envData, [factor]: newList},
            modificationsMap: newModsMap
        };
    }),

    // --- 运行预测 (提交到后端) ---
    runPrediction: async () => {
        set({status: 'loading', error: null});

        const state = get();

        // 1. 校验：如果开启了环境模拟，必须有坐标和环境数据
        if (state.useEnvironment) {
            if (!state.coordinates || !state.envData) {
                set({status: 'error', error: "Missing environment data or coordinates."});
                return;
            }
        }

        // 2. 构造 FormData
        const formData = new FormData();

        if (state.file) {
            formData.append('file', state.file);
        } else {
            set({status: 'error', error: "Please upload a genotype file."});
            return;
        }

        // 3. 构造 payload (修改点)
        // 我们只在 useEnvironment 为 true 时发送 envData
        const payload = {
            coordinates: state.coordinates,
            useEnvironment: state.useEnvironment,
            // 关键修改：如果开关关闭，强制传 null，后端会据此跳过校验
            envData: state.useEnvironment ? state.envData : null
        };

        formData.append('data', JSON.stringify(payload));

        try {
            const response = await fetch('/api/predict', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                // 尝试读取后端返回的详细错误信息
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || "Prediction failed");
            }

            const result = await response.json();

            set({
                status: 'success',
                predictionResult: result.data
            });

        } catch (err: any) {
            console.error(err);
            set({status: 'error', error: err.message});
        }
    },

    addModification: (factor, mod) => {
        const {envData, modificationsMap} = get();
        if (!envData || !envData[factor]) return;

        const currentMods = modificationsMap[factor] || [];
        const newMods = [...currentMods, mod];
        const newDataPoints = recalculateValues(envData[factor], newMods);

        set({
            modificationsMap: {...modificationsMap, [factor]: newMods},
            envData: {...envData, [factor]: newDataPoints}
        });
    },

    removeModification: (factor, modId) => {
        const {envData, modificationsMap} = get();
        if (!envData || !envData[factor]) return;

        const currentMods = modificationsMap[factor] || [];
        const newMods = currentMods.filter(m => m.id !== modId);
        const newDataPoints = recalculateValues(envData[factor], newMods);

        set({
            modificationsMap: {...modificationsMap, [factor]: newMods},
            envData: {...envData, [factor]: newDataPoints}
        });
    },

    clearModifications: (factor) => {
        const {envData, modificationsMap} = get();
        if (!envData || !envData[factor]) return;

        const newMods: Modification[] = [];
        const newDataPoints = recalculateValues(envData[factor], newMods);

        set({
            modificationsMap: {...modificationsMap, [factor]: newMods},
            envData: {...envData, [factor]: newDataPoints}
        });
    },

    isResultModalOpen: false,
    openResultModal: () => set({isResultModalOpen: true}),
    closeResultModal: () => set({isResultModalOpen: false}),
}));
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

import tailwindcss from '@tailwindcss/vite'
import { tanstackRouter } from '@tanstack/router-plugin/vite'
import * as path from "path";

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    tanstackRouter(),
    react(),
    tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    proxy: {
      // 将所有 /api 开头的请求代理到 FastAPI
      '/api': {
        target: 'http://localhost:8000', // 你的 FastAPI 地址
        changeOrigin: true,              // 修改请求头中的源
        secure: false,                   // 忽略 HTTPS 校验（如需）
        rewrite: (path) => path.replace(/^\/api/, '/api'), // 可按需重写路径
      },
    },
  },
})